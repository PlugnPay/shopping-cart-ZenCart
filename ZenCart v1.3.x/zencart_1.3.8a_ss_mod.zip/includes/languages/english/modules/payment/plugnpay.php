<?php
//
// +----------------------------------------------------------------------+
// |zen-cart Open Source E-commerce                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 2003 The zen-cart developers                           |
// |                                                                      |   
// | http://www.zen-cart.com/index.php                                    |   
// |                                                                      |   
// | Portions Copyright (c) 2003 osCommerce                               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.zen-cart.com/license/2_0.txt.                             |
// | If you did not receive a copy of the zen-cart license and are unable |
// | to obtain it through the world-wide-web, please send a note to       |
// | license@zen-cart.com so we can mail you a copy immediately.          |
// +----------------------------------------------------------------------+
// | PlugnPay Smart Screens Payment Module for ZenCart v1.3.0.2           |
// | Module created by PlugnPay Technologies, Inc.                        |
// | Released under GPL                                                   |
// | Last Updated: 07/19/06                                               |
// +----------------------------------------------------------------------+

  define('MODULE_PAYMENT_PLUGNPAY_TEXT_TITLE', 'PlugnPay');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_DESCRIPTION', 'PlugnPay Smart Screens');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_TYPE', 'Type:');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_CREDIT_CARD_OWNER', 'Name On Card:');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_CREDIT_CARD_NUMBER', 'Credit Card Number:');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_CREDIT_CARD_CVV', 'CVV/CVV2:');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_CREDIT_CARD_EXPIRES', 'Credit Card Expiry Date:');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_JS_CC_NUMBER', '* The credit card number must be at least ' . CC_NUMBER_MIN_LENGTH . ' characters.\n');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_JS_CC_OWNER', '* The owner\'s name of the credit card must be at least ' . CC_OWNER_MIN_LENGTH . ' characters.\n');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_ERROR_MESSAGE', 'There has been an error processing your credit card, please try again.');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_ERROR', 'Credit Card Error!');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_PAYTYPE', 'Payment Method:');
?>
