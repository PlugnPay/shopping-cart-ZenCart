<?php
//
// +----------------------------------------------------------------------+
// |zen-cart Open Source E-commerce                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 2003 The zen-cart developers                           |
// |                                                                      |   
// | http://www.zen-cart.com/index.php                                    |   
// |                                                                      |   
// | Portions Copyright (c) 2003 osCommerce                               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.zen-cart.com/license/2_0.txt.                             |
// | If you did not receive a copy of the zen-cart license and are unable |
// | to obtain it through the world-wide-web, please send a note to       |
// | license@zen-cart.com so we can mail you a copy immediately.          |
// +----------------------------------------------------------------------+
// | PlugnPay Smart Screens Payment Module for ZenCart v1.3.0.2           |
// | Module created by PlugnPay Technologies, Inc.                        |
// | Released under GPL                                                   |
// | Last Updated: 07/19/06                                               |
// +----------------------------------------------------------------------+

  class plugnpay extends base {
    var $code, $title, $description, $enabled;
    var $accepted_cc, $card_types, $allowed_types;

// class constructor
    function plugnpay() {

      $this->code = 'plugnpay';
      $this->title = MODULE_PAYMENT_PLUGNPAY_TEXT_TITLE;
      $this->description = MODULE_PAYMENT_PLUGNPAY_TEXT_DESCRIPTION;
      $this->enabled = ((MODULE_PAYMENT_PLUGNPAY_STATUS == 'True') ? true : false); // Whether the module is installed
      $this->sort_order = MODULE_PAYMENT_PLUGNPAY_SORT_ORDER; // Sort Order of payment option on the customer payment page

      $this->form_action_url = 'https://pay1.plugnpay.com/payment/pay.cgi';
      //$this->form_action_url = 'https://pay1.plugnpay.com/payment/' . MODULE_PAYMENT_PLUGNPAY_LOGIN . 'pay.cgi';
      // * NOTE: Use the above line, when you want to use the old 'usernamepay.cgi' payment script.

      $this->accepted_cc = MODULE_PAYMENT_PLUGNPAY_ACCEPTED_CC;

      //array for credit card selection
      $this->card_types = array('Amex' => 'amex',
                                'Mastercard' => 'mastercard',
                                'Discover' => 'discover',
                                'Visa' => 'visa');

      $this->allowed_types = array();

      // produce credit card allowed list
      $cc_array = explode(', ', MODULE_PAYMENT_PLUGNPAY_ACCEPTED_CC);
      while (list($key, $value) = each($cc_array)) {
        $this->allowed_types[$value] = $this->card_types[$value];
      }

      if ((int)MODULE_PAYMENT_PLUGNPAY_ORDER_STATUS_ID > 0) {
        $this->order_status = MODULE_PAYMENT_PLUGNPAY_ORDER_STATUS_ID;
      }

      if (is_object($order)) $this->update_status();
    }

    //concatenate to get CC images
    function get_cc_images() {
      $cc_images = '';
      reset($this->allowed_types);
      while (list($key, $value) = each($this->allowed_types)) {
        $cc_images .= zen_image(DIR_WS_IMAGES . 'icons/' . $key . '.gif', $value);
      }
      return $cc_images;
    }

    function update_status() {
      global $order, $db;

      if ( ($this->enabled == true) && ((int)MODULE_PAYMENT_PLUGNPAY_ZONE > 0) ) {
        $check_flag = false;
        $check = $db->Execute("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_PLUGNPAY_ZONE . "' and zone_country_id = '" . $order->billing['country']['id'] . "' order by zone_id");
        while (!$check->EOF) {
          if ($check->fields['zone_id'] < 1) {
            $check_flag = true;
            break;
          } elseif ($check->fields['zone_id'] == $order->billing['zone_id']) {
            $check_flag = true;
            break;
          }
          $check->MoveNext();
        }

        if ($check_flag == false) {
          $this->enabled = false;
        }
      }
    }

// class methods
    function javascript_validation() {
      $js = '  if (payment_value == "' . $this->code . '") {' . "\n" .
            '    var cc_owner = document.checkout_payment.cc_owner.value;' . "\n" .
            '    var cc_number = document.checkout_payment.cc_number.value;' . "\n" .
            '    if (cc_owner == "" || cc_owner.length < ' . CC_OWNER_MIN_LENGTH . ') {' . "\n" .
            '      error_message = error_message + "' . MODULE_PAYMENT_PLUGNPAY_TEXT_JS_CC_OWNER . '";' . "\n" .
            '      error = 1;' . "\n" .
            '    }' . "\n" .
            '    if (cc_number == "" || cc_number.length < ' . CC_NUMBER_MIN_LENGTH . ') {' . "\n" .
            '      error_message = error_message + "' . MODULE_PAYMENT_PLUGNPAY_TEXT_JS_CC_NUMBER . '";' . "\n" .
            '      error = 1;' . "\n" .
            '    }' . "\n" .
            '  }' . "\n";

      return $js;
    }

    function selection() {

      if (MODULE_PAYMENT_PLUGNPAY_PAYMETHOD == 'onlinecheck') {
        # set paytype menu
        $paytype_menu[] = array('id' => 'credit_card', 'text' => 'Credit Card');
        $paytype_menu[] = array('id' => 'onlinecheck', 'text' => 'Electronic Check');
      }

      if (MODULE_PAYMENT_PLUGNPAY_PAYMETHOD == 'onlinecheck') {
        $selection = array('id' => $this->code,
                     'module' => $this->title. '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $this->get_cc_images() . '&nbsp; or Electronic Check',
                     'fields' => array(
                                        // credit & echeck selection
                                        array('title' => '<b>Select Your Method Of Payment:</b>',
                                              'field' => ''),
                                        array('title' => MODULE_PAYMENT_PLUGNPAY_TEXT_PAYTYPE,
                                              'field' => zen_draw_pull_down_menu('plugnpay_paytype', $paytype_menu))
                                      ));
      }
      else {
        $selection = array('id' => $this->code,
                   'module' => $this->title. '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $this->get_cc_images());

      }

      return $selection;

    }

    function pre_confirmation_check() {
      return false;
    }

    function confirmation() {
      return false;
    }

    function process_button() {
      global $HTTP_POST_VARS, $shipping_selected, $shipping_cost, $shipping_method,
             $total_cost, $total_tax, $order, $currencies, $customer_id, $sendto;

      $cc_allowed_types = '';
      reset($this->allowed_types);
      while (list($key, $value) = each($this->allowed_types)) {
        $cc_allowed_types .= $value . ",";
      }

      # generate pnp orderid so that we don't get duplicates
      $pnp_date = date("YmdHis");
      $pnp_orderID = $pnp_date . substr(getmypid(),0,3);
 
      $process_button_string = zen_draw_hidden_field('publisher-name', MODULE_PAYMENT_PLUGNPAY_LOGIN) .
                               zen_draw_hidden_field('publisher-email', MODULE_PAYMENT_PLUGNPAY_PUBLISHER_EMAIL) .
                               zen_draw_hidden_field('card-amount', number_format($order->info['total'], 2)) .
                               zen_draw_hidden_field('easycart', '1') .
                               zen_draw_hidden_field('shipinfo', '1') .
                               zen_draw_hidden_field('nostatelist', 'yes') .
                               zen_draw_hidden_field('client', 'osCommerce_DM') .
                               zen_draw_hidden_field('currency', $order->info['currency']) .
                               zen_draw_hidden_field('orderID', $pnp_orderID) .
                               zen_draw_hidden_field('order-id', $customer_id) .
                               zen_draw_hidden_field('dontsndmail', (MODULE_PAYMENT_PLUGNPAY_EMAIL == 'Yes'? 'YES': 'NO')) .
                               zen_draw_hidden_field('card-allowed', $cc_allowed_types) .
                               zen_draw_hidden_field('success-link', HTTP_SERVER . DIR_WS_CATALOG . "order_process_plugnpay.php");

      if (MODULE_PAYMENT_PLUGNPAY_PAYMETHOD == 'onlinecheck') {
        $process_button_string .= zen_draw_hidden_field('paymethod', $HTTP_POST_VARS['plugnpay_paytype']);
      }

      if (MODULE_PAYMENT_PLUGNPAY_AVS_LEVEL != 0){
        $process_button_string .= zen_draw_hidden_field('app-level', MODULE_PAYMENT_PLUGNPAY_AVS_LEVEL);
      }

      #### put in itemized order details here.
      #require(DIR_WS_CLASSES . 'order.php'); # Not required becuase it is already defined
      $pnp_order = new order;
      $pnp_tax = 0;

      for ($i=0, $n=sizeof($pnp_order->products); $i<$n; $i++) {
        $j = $i + 1;
        $process_button_string .= zen_draw_hidden_field("item$j", $pnp_order->products[$i]['model']);
        $process_button_string .= zen_draw_hidden_field("cost$j", $pnp_order->products[$i]['final_price']);
        $process_button_string .= zen_draw_hidden_field("quantity$j", $pnp_order->products[$i]['qty']);
        $process_button_string .= zen_draw_hidden_field("description$j", $pnp_order->products[$i]['name']);

        $pnp_tax += ($pnp_order->products[$i]['final_price'] * $pnp_order->products[$i]['qty']) * ($order->products[$i]['tax'] / 100);
      }
      ###########################

      $process_button_string .= zen_draw_hidden_field("shipping", $order->info['shipping_cost']);
      $process_button_string .= zen_draw_hidden_field("tax", $pnp_tax);

      # billing address info
      $process_button_string .= zen_draw_hidden_field('order-id', $customer_id) .
                                zen_draw_hidden_field('card-name', $order->billing['firstname'] . ' ' . $order->billing['lastname']) .
                                zen_draw_hidden_field('card-company', $order->billing['company']) . 
                                zen_draw_hidden_field('card-address1', $order->billing['street_address']) .
                                zen_draw_hidden_field('card-city', $order->billing['city']) .
                                zen_draw_hidden_field('card-prov', $order->billing['suburb']) .
                                zen_draw_hidden_field('card-state', $order->billing['state']) .
                                zen_draw_hidden_field('card-zip', $order->billing['postcode']) .
                                zen_draw_hidden_field('card-country', $order->billing['country']['iso_code_2']) .
                                zen_draw_hidden_field('phone', $order->customer['telephone']) .
                                zen_draw_hidden_field('fax', $order->customer['fax']) .
                                zen_draw_hidden_field('email', $order->customer['email_address']);

      # shipping address info
      $process_button_string .= zen_draw_hidden_field('shipname', $order->delivery['firstname'] . ' ' . $order->delivery['lastname']) .
                                zen_draw_hidden_field('shipcompany', $order->delivery['company']) .
                                zen_draw_hidden_field('address1', $order->delivery['street_address']) .
                                zen_draw_hidden_field('city', $order->delivery['city']) .
                                zen_draw_hidden_field('province', $order->delivery['suburb']) .
                                zen_draw_hidden_field('state', $order->delivery['state']) .
                                zen_draw_hidden_field('zip', $order->delivery['postcode']) .
                                zen_draw_hidden_field('country', $order->delivery['country']['iso_code_2']);

      $process_button_string .= zen_draw_hidden_field(zen_session_name(), zen_session_id());

      return $process_button_string;
    }

    function before_process() {
      return false;
    }

    function after_process() {
      return false;
    }

    function output_error() {
      return false;
    }

    function check() {
      global $db;
      if (!isset($this->check)) {
        $check_query = $db->Execute("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_PLUGNPAY_STATUS'");
        $this->check = $check_query->RecordCount();
      }
      return $this->check;
    }

    function install() {
      global $db;
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Enable PlugnPay Module', 'MODULE_PAYMENT_PLUGNPAY_STATUS', 'True', 'Do you want to accept payments through PlugnPay?', '6', '0', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Login Username', 'MODULE_PAYMENT_PLUGNPAY_LOGIN', 'Your Login Name', 'Enter your PlugnPay account username', '6', '0', now())");
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('PlugnPay Publisher Email', 'MODULE_PAYMENT_PLUGNPAY_PUBLISHER_EMAIL', 'you@yourdomain.com', 'The email address you want PlugnPay merchant confirmations to go to.', '6', '0', now())");
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('PlugnPay AVS Level', 'MODULE_PAYMENT_PLUGNPAY_AVS_LEVEL', '0', 'The level of address verification you wish to have. Levels 1-6 0=Off.', '6', '4', now())");
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('PlugnPay dontsndmail', 'MODULE_PAYMENT_PLUGNPAY_DONTSNDMAIL', 'No', 'Do not send PlugnPay email to the customer?', '6', '0', 'zen_cfg_select_option(array(\'Yes\', \'No\'), ', now())");
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Transaction Method', 'MODULE_PAYMENT_PLUGNPAY_PAYMETHOD', 'credit', 'Transaction method used for processing orders.<br><b>NOTE:</b> Selecting \'onlinecheck\' assumes you\'ll offer \'credit\' as well.', '6', '0', 'zen_cfg_select_option(array(\'credit\', \'onlinecheck\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, use_function, set_function, date_added) values ('Payment Zone', 'MODULE_PAYMENT_PLUGNPAY_ZONE', '0', 'If a zone is selected, only enable this payment method for that zone.', '6', '2', 'zen_get_zone_class_title', 'zen_cfg_pull_down_zone_classes(', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Order Status', 'MODULE_PAYMENT_PLUGNPAY_ORDER_STATUS_ID', '0', 'Set the status of orders made with this payment module to this value', '6', '0', 'zen_cfg_pull_down_order_statuses(', 'zen_get_order_status_name', now())");
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Accepted Credit Cards', 'MODULE_PAYMENT_PLUGNPAY_ACCEPTED_CC', 'Mastercard, Visa', 'The credit cards you currently accept', '6', '0', '_selectOptions(array(\'Amex\', \'Discover\', \'Mastercard\', \'Visa\'), ', now())");
    }

    function remove() {
      global $db;
      $keys = '';
      $keys_array = $this->keys();
      for ($i=0; $i<sizeof($keys_array); $i++) {
        $keys .= "'" . $keys_array[$i] . "',";
      }
      $keys = substr($keys, 0, -1);
      $db->Execute("delete from " . TABLE_CONFIGURATION . " where configuration_key in (" . $keys . ")");
    }

    function keys() {
      $keys = array('MODULE_PAYMENT_PLUGNPAY_STATUS', 'MODULE_PAYMENT_PLUGNPAY_LOGIN', 'MODULE_PAYMENT_PLUGNPAY_PUBLISHER_EMAIL', 'MODULE_PAYMENT_PLUGNPAY_AVS_LEVEL', 'MODULE_PAYMENT_PLUGNPAY_DONTSNDMAIL', 'MODULE_PAYMENT_PLUGNPAY_PAYMETHOD', 'MODULE_PAYMENT_PLUGNPAY_ZONE', 'MODULE_PAYMENT_PLUGNPAY_ORDER_STATUS_ID', 'MODULE_PAYMENT_PLUGNPAY_ACCEPTED_CC');

      return $keys;
    }
  }

// PlugnPay Consolidated Credit Card Checkbox Implementation
// Code from UPS Choice v1.7
function _selectOptions($select_array, $key_value, $key = '') {
  for ($i=0; $i<(sizeof($select_array)); $i++) {
    $name = (($key) ? 'configuration[' . $key . '][]' : 'configuration_value');
    $string .= '<br><input type="checkbox" name="' . $name . '" value="' . $select_array[$i] . '"';
    $key_values = explode(", ", $key_value);
    if (in_array($select_array[$i], $key_values)) $string .= ' checked="checked"';
    $string .= '> ' . $select_array[$i];
  } 
  return $string;
}

?>
