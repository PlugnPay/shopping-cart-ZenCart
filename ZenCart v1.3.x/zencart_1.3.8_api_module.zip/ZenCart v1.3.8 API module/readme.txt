====================================================
PlugnPay API Module (Credit Card Payments)
Payment Module for ZenCart v1.3.8
====================================================

***** IMPORTANT NOTES *****
This module is being provided "AS IS".  Limited technical support assistance will
be given to help diagnose/address problems with this module.  The amount of support
provided is up to PlugnPay's staff.

It is recommended if you experience a problem with this module, first seek assistance
through this module's readme file, then check with the ZenCart community at
'www.zencart.com', and if you are still unable to resolve the issue, contact us
via PlugnPay's Online Helpdesk.

This module requires your server to have SSL abilities & CURL.  ZenCart will ask the
customer for all of their credit card info on your server's SSL secured billing pages.
The authorization will be done via PlugnPay's API payment method.  The module is
intended to itemize the order in the PlugnPay system using available information from
the cart.

If you want to change the behavior of this module, please feel free to make changes
to the files yourself.  However, customized ZenCart modules will not be provided
support assistance.

In addition, you should have the 'Enable secure SSL/HTTPS connections' option enabled
in your ZenCart shopping cart to properly use this module.
***************************

This module is designed to use PlugnPay's API payment method, via cURL.
Its also designed for processing credit card payments only.
Please install other PlugnPay modules for alternative payment abilities.  

This module is intended to charge customer's order as a single payment.
This single payment is applied at time of the customer's purchase.

To Install:

1. Copy the zencart_root/includes/languages/english/modules/payment/plugnpay_api.php file to the
corresponding file in your zencart install on your web server.

2. Do the same with zencart_root/modules/payment/plugnpay_api.php

3. Copy the plugnpay_debug.txt file to root folder where zencart is installed on your web server.

4. Go into your admin panel and activate the PlugnPay APP payment module on the payment modules
page and fill in the appropriate data


If you run into problems:

Check to be sure you actually uploaded the files in the correct folders.

Check the uploaded file's permissions:
-- .php files should be chmod 755
   (read/write/execute by owner, read/execute by all others)
-- .txt files should be chmod 666
   (read/write by all [owner, group & nobody user])

When processing a transaction and it fails, there should be a PnP generated error 
message after the '--' in the response in your shopping cart.  This would tell the 
customer why PnP could not process the order.  If this is blank, then you should check
your cURL connection. 

There are 2 ways to check the cURL connection:

1 - Turn on the Test option, run a transaction and then look at the 
    'plugnpay_debug.txt' file in your catalog folder.
    -- The PREAUTH line is the string that was sent to PnP's servers via the cURL 
       connection.
    -- The POSTAUTH line is the string that was received by your cURL connection from
       PnP server.
    -- When the POSTAUTH line is blank, this means cURL did not make a connection to 
       PnP servers & is best to manually test cURL with the 2nd way below. 

2 - You can check this out by accessing the server via a shell account (SSH/Telnet) & 
    manually running a cURL connection.
    Run the following command from the command line of the server's shell and see if you 
    get a response string.

   /usr/bin/curl -d "publisher-name=pnpdemo&publisher-email=trash%40plugnpay.com&mode=auth&card-name=cardtest&card-number=4111111111111111&card-exp=0112&card-cvv=123&card-amount=1.23" https://pay1.plugnpay.com/payment/pnpremote.cgi
 

 *NOTES:
 -- THE ABOVE COMMAND SHOULD ALL BE ON ONE LINE
 -- You should adjust the path to curl (/usr/bin/curl) to whatever your server uses.
 -- You should get a response string similar to the one below.
 
 You should get a response string should look something like this, if it was successful.

FinalStatus=success&IPaddress=123%2e45%2e67%2e89&MStatus=success&User%2dAgent=curl%2f7%2e12%2e1%20%28i386%2dredhat%2dlinux%2dgnu%29%20libcurl%2f7%2e12%2e1%20OpenSSL%2f0%2e9%2e7a%20zlib%2f1%2e2%2e2%2e2%20libidn%2f0%2e5%2e6&auth%2dcode=TSTAUT&auth%2dmsg=%2000%3a&auth_date=20060718&avs%2dcode=U&card%2damount=1%2e23&card%2dname=cardtest&card%2dtype=VISA&currency=usd&cvvresp=M&easycart=0&merchant=pnpdemo&mode=auth&orderID=2006071821390221195&publisher%2demail=trash%40plugnpay%2ecom&publisher%2dname=pnpdemo&resp%2dcode=00&resphash=a84f2bf05b83fc7677e7da9ded14d8f3&shipinfo=0&sresp=A&success=yes&transflags=retail&MErrMsg=00%3a&a=b

 * NOTE: THE ABOVE SHOULD ALL BE ON ONE LINE

If you get a certificate validation error, you can enter '-k' attribute between the path 
to curl & the '-d' parameter.  The '-k' parameter will turn off the SSL certificate 
validation.
 
If you get back a blank response there is most likely a firewall which is internal to 
your server/network which is preventing cURL from contacting our servers.
 
If cURL complied into your PHP is not working, but the command line cURL connection 
worked, use Not Compiled option & that same path to curl you used in your command line.

If this hasn't still fixed the issue, here are a few other suggestions.  You may want
to check the following: 

  * Ensure your path to cURL is correctly inputted, if in Not Compiled mode.

  * If in Compiled mode, check if cURL is in fact compiled and working.

  * Ensure SSL abilities on your server are working & updated with the latest certificates.

  * Remove & then Install the PlugnPay API module via the Admin panel, if you upgraded
    from a previous version or modified the source code of any of our module's files.

  * Ensure your PlugnPay username is inputted correctly into the Login ID field.

  * Ensure your PlugnPay account is actually 'Live' & ZenCart is set in Production status, 
    so you can process real credit card transactions.

  * Ensure you have properly set up your PlugnPay account via our website, including setting
    all your Fraud settings & make sure your account is 'Live'.

Also, realize that this code itself is not very complex, and practically every person 
that has contacted us about errors found that some other code not associated with this
contribution was responsible, they forgot to install one of our module's files or because
their cURL implementation was not properly set up or working.  Do your own debugging
before contacting anyone for assistance.

-----------------------------------------------------------------------------
Updates:

12/26/08
-- wrote initial ZenCart API module, specifically for ZenCart build v1.3.8
-- tried to give similar features/options as previous ZenCart modules.

