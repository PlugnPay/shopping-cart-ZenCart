<?php
/**
 * PlugnPay API Module Version 0.2
 *
 * @package paymentMethod
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: plugnpay_api.php 5436 2008-12-26 19:09:50Z AphelionZ $
 */
/*
#######################################################################
# Original module written by Mark Henderson (henderson.mark@gmail.com)
# Modified by PlugnPay for use with our payment gateway services.
#######################################################################
*/

// Admin section
  define('MODULE_PAYMENT_PLUGNPAY_API_TEXT_ADMIN_TITLE', 'PlugnPay API');
  define('MODULE_PAYMENT_PLUGNPAY_API_TEXT_DESCRIPTION', 
    'PlugnPay API Credit Card');

// Form field labels
  define('MODULE_PAYMENT_PLUGNPAY_API_TEXT_CATALOG_TITLE', 'Credit Card (API)');
  // ^^ Payment option title as displayed to the customer in checkout ^^
  define('MODULE_PAYMENT_PLUGNPAY_API_TEXT_CREDIT_CARD_TYPE', 'Credit Card Type:');
  define('MODULE_PAYMENT_PLUGNPAY_API_TEXT_CREDIT_CARD_OWNER', 'Credit Card Owner:');
  define('MODULE_PAYMENT_PLUGNPAY_API_TEXT_CREDIT_CARD_NUMBER', 'Credit Card Number:');
  define('MODULE_PAYMENT_PLUGNPAY_API_TEXT_CREDIT_CARD_EXPIRES', 'Credit Card Expiry Date:');
  define('MODULE_PAYMENT_PLUGNPAY_API_TEXT_CVV', 'CVV Number:');
  define('MODULE_PAYMENT_PLUGNPAY_API_TEXT_POPUP_CVV_LINK', 'Where is my CVV Number?');

// JS error messages
  define('MODULE_PAYMENT_PLUGNPAY_API_TEXT_JS_CC_OWNER', '* The owner\'s name of the credit card must be at least ' . CC_OWNER_MIN_LENGTH . ' characters.\n');
  define('MODULE_PAYMENT_PLUGNPAY_API_TEXT_JS_CC_NUMBER', '* The credit card number must be at least ' . CC_NUMBER_MIN_LENGTH . ' characters.\n');
  define('MODULE_PAYMENT_PLUGNPAY_API_TEXT_JS_CC_CVV', '* The 3 or 4 digit CVV number must be entered from the back of the credit card.\n');
  
// Other error messages
  define('MODULE_PAYMENT_PLUGNPAY_API_TEXT_DECLINED_MESSAGE', 'There has been an error processing your credit card. Please try again.');
  /*define('MODULE_PAYMENT_PLUGNPAY_TEXT_GATEWAY_TIMEOUT', 'There was an error contacting the credit card processor. Please try again.');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_ERROR', 'There was a problem processing your Credit Card! Not-Approved.');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_WRONG_TYPE', 'The Credit Card Number does not match the Credit Card Type.');
  */
  
?>
