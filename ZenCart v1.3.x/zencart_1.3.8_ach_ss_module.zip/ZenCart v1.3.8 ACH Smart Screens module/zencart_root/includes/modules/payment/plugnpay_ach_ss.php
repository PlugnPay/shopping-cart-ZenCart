<?php
/**
 * PlugnPay ACH Smart Screens payment method class
 *
 * @package paymentMethod
 * @copyright Copyright 2003-2007 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: plugnpay_ach_ss.php 7620 2009-01-24 12:00:00Z drbyte $
 */
/**
 * PlugnPay ACH smart screens payment method class
 *
 */
class plugnpay_ach_ss extends base {
  var $code, $title, $description, $enabled;

  // class constructor
  function plugnpay_ach_ss() {
    global $order;

    $this->signature = 'plugnpay|plugnpay_ach_ss|1.0|2.2';

    $this->code = 'plugnpay_ach_ss';
    if (IS_ADMIN_FLAG === true) {
      $this->title = MODULE_PAYMENT_PLUGNPAY_ACH_SS_TEXT_ADMIN_TITLE; // Payment module title in Admin
    } else {
      $this->title = MODULE_PAYMENT_PLUGNPAY_ACH_SS_TEXT_CATALOG_TITLE; // Payment module title in Catalog
    }
    $this->description = MODULE_PAYMENT_PLUGNPAY_ACH_SS_TEXT_DESCRIPTION;
    $this->enabled = ((MODULE_PAYMENT_PLUGNPAY_ACH_SS_STATUS == 'True') ? true : false);
    $this->sort_order = MODULE_PAYMENT_PLUGNPAY_ACH_SS_SORT_ORDER;

    if ((int)MODULE_PAYMENT_PLUGNPAY_ACH_SS_ORDER_STATUS_ID > 0) {
      $this->order_status = MODULE_PAYMENT_PLUGNPAY_ACH_SS_ORDER_STATUS_ID;
    }

    if (is_object($order)) $this->update_status();
    $this->form_action_url = 'https://pay1.plugnpay.com/payment/pay.cgi';
  }

  // class methods
  function update_status() {
    global $order, $db;

    if (($this->enabled == true) && ((int)MODULE_PAYMENT_PLUGNPAY_ACH_SS_ZONE > 0)) {
      $check_flag = false;
      $check = $db->Execute("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_PLUGNPAY_ACH_SS_ZONE . "' and zone_country_id = '" . $order->billing['country']['id'] . "' order by zone_id");
      while (!$check->EOF) {
        if ($check->fields['zone_id'] < 1) {
          $check_flag = true;
          break;
        } elseif ($check->fields['zone_id'] == $order->billing['zone_id']) {
          $check_flag = true;
          break;
        }
        $check->MoveNext();
      }

      if ($check_flag == false) {
        $this->enabled = false;
      }
    }
  }

  function javascript_validation() {
    return false;
  }

  function selection() {
    return array('id' => $this->code,
                 'module' => $this->title);
  }

  function pre_confirmation_check() {
    return false;
  }

  function confirmation() {
    return false;
  }

  function process_button() {
    global $customer_id, $order, $sendto, $currency;

    # generate pnp orderid so that we don't get duplicates
    $pnp_date = date("YmdHis");
    $pnp_orderID = $pnp_date . substr(getmypid(),0,3);

    # basic settings
    $process_button_string .= zen_draw_hidden_field('publisher-name', MODULE_PAYMENT_PLUGNPAY_ACH_SS_LOGIN) .
                              zen_draw_hidden_field('publisher_email', MODULE_PAYMENT_PLUGNPAY_ACH_SS_PUBEMAIL) .
                              zen_draw_hidden_field('client', 'ZenCart_ACH_SS') .
                              zen_draw_hidden_field('paymethod', 'onlinecheck') .
                              zen_draw_hidden_field('convert', 'underscores') .
                              zen_draw_hidden_field('easycart', '1') .
                              zen_draw_hidden_field('shipinfo', '0') .
                              zen_draw_hidden_field('nostatelist', 'yes') .
                              zen_draw_hidden_field('orderID', $pnp_orderID) .
                              zen_draw_hidden_field('currency', $currency) .
                              zen_draw_hidden_field('card_amount', $order->info['total']) .
                              zen_draw_hidden_field('authtype', ((MODULE_PAYMENT_PLUGNPAY_ACH_SS_AUTHTYPE == 'authpostauth') ? 'authpostauth' : 'authonly')) .
                              zen_draw_hidden_field('success_link', zen_href_link(FILENAME_CHECKOUT_PROCESS, '', 'SSL', false)) .
                              zen_draw_hidden_field('badcard_link', zen_href_link(FILENAME_CHECKOUT_PROCESS, '', 'SSL', false)) .
                              zen_draw_hidden_field('problem_link', zen_href_link(FILENAME_CHECKOUT_PROCESS, '', 'SSL', false));

    # billing address info
    $process_button_string .= zen_draw_hidden_field('card_name', $order->billing['firstname'] . ' ' . $order->billing['lastname']) .
                              zen_draw_hidden_field('card_company', $order->billing['company']) .
                              zen_draw_hidden_field('card_address1', $order->billing['street_address']) .
                              zen_draw_hidden_field('card_city', $order->billing['city']) .
                              zen_draw_hidden_field('card-prov', $order->billing['suburb']) .
                              zen_draw_hidden_field('card_state', $order->billing['state']) .
                              zen_draw_hidden_field('card_zip', $order->billing['postcode']) .
                              zen_draw_hidden_field('card_country', $order->billing['country']['iso_code_2']);

/*
    # shipping address info
    if (is_numeric($sendto) && ($sendto > 0)) {
      $process_button_string .= zen_draw_hidden_field('shipname', $order->delivery['firstname'] . ' ' . $order->delivery['lastname']) .
                                zen_draw_hidden_field('company', $order->delivery['company']) .
                                zen_draw_hidden_field('address1', $order->delivery['street_address']) .
                                zen_draw_hidden_field('city', $order->delivery['city']) .
                                zen_draw_hidden_field('province', $order->delivery['suburb']) .
                                zen_draw_hidden_field('state', $order->delivery['state']) .
                                zen_draw_hidden_field('zip', $order->delivery['postcode']) .
                                zen_draw_hidden_field('country', $order->delivery['country']['iso_code_2']);
    }
*/

    # other customer info
    $process_button_string .= zen_draw_hidden_field('email', $order->customer['email_address']) .
                              zen_draw_hidden_field('phone', $order->customer['telephone']) .
                              zen_draw_hidden_field('order_id', $customer_id) .
                              zen_draw_hidden_field('ipaddress', zen_get_ip_address());
    # AVS setting
    if (MODULE_PAYMENT_PLUGNPAY_ACH_SS_AVS_LEVEL != 0){
      $process_button_string .= zen_draw_hidden_field('app_level', MODULE_PAYMENT_PLUGNPAY_ACH_SS_AVS_LEVEL);
    }


    # itemized product details
    for ($i=0, $n=sizeof($order->products); $i<$n; $i++) {
      $j = $i + 1;
      $process_button_string .= zen_draw_hidden_field("item$j", $order->products[$i]['model']);
      $process_button_string .= zen_draw_hidden_field("cost$j", $order->products[$i]['final_price']);
      $process_button_string .= zen_draw_hidden_field("quantity$j", $order->products[$i]['qty']);
      $process_button_string .= zen_draw_hidden_field("description$j", $order->products[$i]['name']);
      $process_button_string .= zen_draw_hidden_field("taxable$i", $order->products[$i]['taxable'] > 0 ? 'Y' : 'N');
    }

    # tax & shipping fee settings
    $tax_value = 0;

    reset($order->info['tax_groups']);
    while (list($key, $value) = each($order->info['tax_groups'])) {
      if ($value > 0) {
        $tax_value += $this->$value;
      }
    }

    if ($tax_value > 0) {
      $process_button_string .= zen_draw_hidden_field('tax', $tax_value);
    }

    $process_button_string .= zen_draw_hidden_field('shipping', $order->info['shipping_cost']) .
                              zen_draw_hidden_field(zen_session_name(), zen_session_id());

    return $process_button_string;
  }

  function before_process() {
    global $messageStack, $_POST, $order;

    $this->result = $_POST;

    $error = false;

/*
    if ($this->result['card_amount'] != $order->info['total']) {
      $messageStack->add_session('checkout_payment', MODULE_PAYMENT_PLUGNPAY_ACH_SS_ERROR_VERIFICATION, 'error');
      zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, ' ', 'SSL', true, false));
    }
*/

    if ($this->result['FinalStatus'] != 'success') {
      if ($this->result['FinalStatus'] == 'badcard') {
        $messageStack->add_session('checkout_payment', MODULE_PAYMENT_PLUGNPAY_ACH_SS_ERROR_BADCARD, 'error');
        zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, ' ', 'SSL', true, false));
      }
      elseif ($this->result['FinalStatus'] == 'problem') {
        $messageStack->add_session('checkout_payment', MODULE_PAYMENT_PLUGNPAY_ACH_SS_ERROR_PROBLEM, 'error');
        zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, ' ', 'SSL', true, false));
      }
      elseif ($this->result['FinalStatus'] == 'fraud') {
        $messageStack->add_session('checkout_payment', MODULE_PAYMENT_PLUGNPAY_ACH_SS_ERROR_FRAUD, 'error');
        zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, ' ', 'SSL', true, false));
      }
      else {
        $messageStack->add_session('checkout_payment', MODULE_PAYMENT_PLUGNPAY_ACH_SS_ERROR_GENERAL, 'error');
        zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, ' ', 'SSL', true, false));
      }
    }

    //echo 'Returned Response Codes:<br /><pre>' . print_r($_POST, true) . '</pre><br />';
    //die('Press the BACK button in your browser to return to the previous page.');
  }

  function after_process() {
    return false;
  }

  function output_error() {
    return false;
  }

  function get_error() {
    $error = array('title' => MODULE_PAYMENT_PLUGNPAY_ACH_SS_TEXT_ERROR,
                   'error' => stripslashes(urldecode($_GET['error'])));

    return $error;
  }

  function check() {
    global $db;
    if (!isset($this->_check)) {
      $check_query = $db->Execute("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_STATUS'");
      $this->_check = $check_query->RecordCount();
    }
    return $this->_check;
  }

  function install() {
    global $db;
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Enable PlugnPay Module', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_STATUS', 'True', 'Do you want to accept PlugnPay payments?', '6', '0', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Login ID', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_LOGIN', 'pnpdemo', 'The Login ID used for the PlugnPay service', '6', '0', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Publisher Email', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_PUBEMAIL', 'trash@plugnpay.com', 'Merchant Confirmation email address used for confirmation emails', '6', '0', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Transaction Method', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_AUTHTYPE', 'authonly', 'The processing method to use for each transaction.', '6', '0', 'zen_cfg_select_option(array(\'authonly\', \'authpostauth\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('AVS Level', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_AVS_LEVEL', '0', 'The level of address verification you wish to have. Levels 1-6 0=Off.', '6', '4', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, use_function, set_function, date_added) values ('Payment Zone', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_ZONE', '0', 'If a zone is selected, only enable this payment method for that zone.', '6', '2', 'zen_get_zone_class_title', 'zen_cfg_pull_down_zone_classes(', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Order Status', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_ORDER_STATUS_ID', '1', 'Set the status of orders made with this payment module to this value', '6', '0', 'zen_cfg_pull_down_order_statuses(', 'zen_get_order_status_name', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Sort order of display.', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_SORT_ORDER', '0', 'Sort order of display. Lowest is displayed first.', '6', '0', now())");
  }

  function remove() {
    global $db;
    $db->Execute("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
  }

  function keys() {
    return array('MODULE_PAYMENT_PLUGNPAY_ACH_SS_STATUS', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_LOGIN', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_PUBEMAIL', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_AUTHTYPE', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_AVS_LEVEL', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_ZONE', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_ORDER_STATUS_ID', 'MODULE_PAYMENT_PLUGNPAY_ACH_SS_SORT_ORDER');
  }

}
?>
