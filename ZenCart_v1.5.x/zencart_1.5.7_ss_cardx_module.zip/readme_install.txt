=================================================
CardX Smart Screens v2 Payment Method
Payment Module for ZenCart v1.5.x
=================================================

***** IMPORTANT NOTES *****
This module is being provided "AS IS".  Limited technical support assistance will
be given to help diagnose/address problems with this module.  The amount of support
provided is up to CardX's staff.

If you experience a problem with this module, first seek assistance through this
module's readme file, then check with the community at 'www.zencart.com'.
If you are still unable to resolve the issue, contact us via CardX's Online Helpdesk.

This module is used without having your own server's SSL abilities. We will ask the
customer for all of their credit card info on our SSL secured billing page on our
secured servers.  The authorization will be done via CardX's Smart Screens payment
method.  The module is intended to itemize the order in the CardX system using
available information from the cart.

If you want to change the behavior of this module, please feel free to make changes
to the files yourself.  However, customized payment modules will not be provided
support assistance.
***************************

Installation:

1. Copy the zencart_root/includes/languages/english/modules/payment/cardx_ss2.php
file to the corresponding place within your shopping cart folder on your web server.

2. Do the same with zencart_root/includes/modules/payment/cardx_ss2.php

3. Go into your admin panel and activate the CardX SSv2 payment module in the
payment modules page and fill in the appropriate data.


Troubleshooting:

Check to be sure you actually uploaded the files in the correct folders;
ensuring you overwrite the existing file, if one exists.

Check the uploaded file's permissions:
-- .php files should be chmod 755
   (read/write/execute by owner, read/execute by all others)

Make sure you have an active merchant account & payment gateway account,
prior to accepting online payments for it.

These are the common issues found by our support staff.

-----------------------------------------------------------------------------
Updates:

03/19/21
- created basic CardX Smart Screens v2 payment module.

