<?php
/**
 * PlugnPay SS2 Payment Module
 *
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: DrByte 2020 May 16 Modified in v1.5.7 $
 */

  define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_ADMIN_TITLE', 'PlugnPay (SSv2)');
  define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_CATALOG_TITLE', 'Credit Card');  // Payment option title as displayed to the customer


  if (defined('MODULE_PAYMENT_PLUGNPAY_SS2_STATUS') && MODULE_PAYMENT_PLUGNPAY_SS2_STATUS == 'True') {
    define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_DESCRIPTION', '<a rel="noreferrer noopener" target="_blank" href="https://pay1.plugnpay.com/admin/">PlugnPay Merchant Login</a>');
  } else {
    define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_DESCRIPTION', '<a rel="noreferrer noopener" target="_blank" href="https://www.plugnpay.com/">Click Here to Sign Up for an Account</a><br /><br /><a rel="noreferrer noopener" target="_blank" href="https://pay1.plugnpay.com/admin/">Click to Login to the PlugnPay Merchant Area</a>');
  }

  define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_TYPE', 'Type:');
  define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_CREDIT_CARD_OWNER', 'Card Owner:');
  define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_CREDIT_CARD_NUMBER', 'Card Number:');
  define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_CREDIT_CARD_EXPIRES', 'Expiry Date:');
  define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_CVV', 'CVV Number:');
  define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_POPUP_CVV_LINK', 'What\'s this?');
  define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_JS_CC_OWNER', '* The owner\'s name of the credit card must be at least ' . CC_OWNER_MIN_LENGTH . ' characters.\n');
  define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_JS_CC_NUMBER', '* The credit card number must be at least ' . CC_NUMBER_MIN_LENGTH . ' characters.\n');
  define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_JS_CC_CVV', '* The 3 or 4 digit CVV number must be entered from the back of the credit card.\n');
  define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_ERROR_MESSAGE', 'There has been an error processing your credit card. Please try again.');
  define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_DECLINED_MESSAGE', 'Your credit card was declined. Please try another card or contact your bank for more info.');
  define('MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_ERROR', 'Credit Card Error!');
