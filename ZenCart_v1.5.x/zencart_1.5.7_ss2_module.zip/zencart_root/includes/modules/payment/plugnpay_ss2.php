<?php
/**
 * PlugnPay SSv2 payment method class
 *
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: DrByte 2020 May 16 Modified in v1.5.7 $
 */
/**
 * PlugnPay SSv2 payment method class
 * Ref: https://www.plugnpay.com/
 */


if (!defined('TABLE_PLUGNPAY'))
  define('TABLE_PLUGNPAY', DB_PREFIX . 'plugnpay_ss2');

class plugnpay_ss2 extends base {
  /**
   * $code determines the internal 'code' name used to designate "this" payment module
   *
   * @var string
   */
  var $code = 'plugnpay_ss2'; // Smart Screens v2
  /**
   * Internal module version string
   * @var string
   */
  var $version = '2021-03-19';
  /**
   * $title is the displayed name for this payment method
   *
   * @var string
   */
  var $title;
  /**
   * $description is a soft name for this payment method
   *
   * @var string
   */
  var $description;
  /**
   * $enabled determines whether this module shows or not... in catalog.
   *
   * @var boolean
   */
  var $enabled = false;
  /**
   * log file folder
   *
   * @var string
   */
  var $_logDir = '';
  /**
   * vars
   */
  var $gateway_mode;
  var $reportable_submit_data;
  var $authorize;
  var $auth_code;
  var $transaction_id;
  var $order_status;
  /**
   * @var string the currency enabled in this gateway's merchant account
   */
  private $gateway_currency;
  /**
   * What order this module displays in relation to other enabled modules
   * @var int $sort_order
   */
  var $sort_order = 0;


  /**
   * Constructor
   */
  function __construct() {
    global $order;

    $this->title = MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_CATALOG_TITLE; // Payment module title in Catalog
    $this->description = MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_DESCRIPTION;

    if (IS_ADMIN_FLAG === true) {
      $this->title = MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_ADMIN_TITLE; // Payment module title in Admin
    }

    $this->sort_order = defined('MODULE_PAYMENT_PLUGNPAY_SS2_SORT_ORDER') ? MODULE_PAYMENT_PLUGNPAY_SS2_SORT_ORDER : null;
    $this->enabled = defined('MODULE_PAYMENT_PLUGNPAY_SS2_STATUS') && MODULE_PAYMENT_PLUGNPAY_SS2_STATUS == 'True';

    if (null === $this->sort_order) return;

    if (IS_ADMIN_FLAG === true) {
      if (MODULE_PAYMENT_PLUGNPAY_SS2_STATUS == 'True' && MODULE_PAYMENT_PLUGNPAY_SS2_LOGIN == 'testing') {
        $this->title .=  '<span class="alert"> (Not Configured)</span>';
      }
    }

    if (defined('MODULE_PAYMENT_PLUGNPAY_SS2_ORDER_STATUS_ID') && (int)MODULE_PAYMENT_PLUGNPAY_SS2_ORDER_STATUS_ID > 0) {
      $this->order_status = MODULE_PAYMENT_PLUGNPAY_SS2_ORDER_STATUS_ID;

      // Reset order status to pending if capture pending:
      if (MODULE_PAYMENT_PLUGNPAY_SS2_AUTHORIZATION_TYPE == 'Authorize') $this->order_status = 1;
    }

    if (is_object($order)) $this->update_status();

    $this->form_action_url = 'https://pay1.plugnpay.com/pay/';
    #$this->form_action_url = 'https://cartdev.urlhitch.com/inputtest.cgi';

    $this->gateway_mode = 'offsite';

    $this->_logDir = defined('DIR_FS_LOGS') ? DIR_FS_LOGS : DIR_FS_SQL_CACHE;

    // verify table structure
    if (IS_ADMIN_FLAG === true) $this->tableCheckup();

    // set the currency for the gateway (others will be converted to this one before submission)
    $this->gateway_currency = MODULE_PAYMENT_PLUGNPAY_SS2_CURRENCY;
  }

  /**
   * Calculate zone matches and flag settings to determine whether this module should display to customers or not
   */
  function update_status() {
    global $order, $db;

    if ($this->enabled && (int)MODULE_PAYMENT_PLUGNPAY_SS2_ZONE > 0 && isset($order->billing['country']['id'])) {
      $check_flag = false;
      $check = $db->Execute("SELECT zone_id FROM " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_PLUGNPAY_SS2_ZONE . "' AND zone_country_id = '" . (int)$order->billing['country']['id'] . "' ORDER BY zone_id");
      while (!$check->EOF) {
        if ($check->fields['zone_id'] < 1) {
          $check_flag = true;
          break;
        } elseif ($check->fields['zone_id'] == $order->billing['zone_id']) {
          $check_flag = true;
          break;
        }
        $check->MoveNext();
      }

      if ($check_flag == false) {
        $this->enabled = false;
      }
    }

    // other status checks?
    if ($this->enabled) {
      // other checks here
    }
  }

  /**
   * JS validation which does error-checking of data-entry if this module is selected for use
   * (Number, Owner Lengths)
   *
   * @return string
   */
  function javascript_validation() {
    return '';
  }

  /**
   * Display Credit Card Information Submission Fields on the Checkout Payment Page
   *
   * @return array
   */
  function selection() {
    global $order;
    return array('id' => $this->code,
                 'module' => $this->title);
  }

  /**
   * Evaluates the Credit Card Type for acceptance and the validity of the Credit Card Number & Expiration Date
   *
   */
  function pre_confirmation_check() {
    //return false;

    global $messageStack;

    if (isset($_POST['pi_response_status'])) {
      $result = false;
      $error = '';
      if ($_POST['pi_response_status'] == 'success') {
        $result = true;
        $error = '';
      }
      else {
        $result = false;
        $error = $_POST['pi_error_message'];
      }

      if ($result == false) {
        $messageStack->add_session('checkout_payment', $error . '<!-- ['.$this->code.'] -->', 'error');
        zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL', true, false));
      }

      $this->cc_card_type = $_POST['pt_card_type'];
      $this->cc_card_number = $_POST['pt_card_number'];
      $this->cc_expiry_month = substr($_POST['pt_card_expiration'],0,2);
      $this->cc_expiry_year = substr($_POST['pt_card_expiration'],-2,2);
    }
  }

  /**
   * Display Credit Card Information on the Checkout Confirmation Page
   *
   * @return array
   */
  function confirmation() {
    global $_POST, $order;

    if (isset($_POST['pt_card_number'])) {
      $confirmation = array('title' => $this->title . ': ' . $this->cc_card_type,
                            'fields' => array(array('title' => MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_CREDIT_CARD_OWNER,
                                                    'field' => $_POST['pt_payment_name']),
                                              array('title' => MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_CREDIT_CARD_NUMBER,
                                                    'field' => $_POST['pt_card_expiration']),
                                              array('title' => MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_CREDIT_CARD_EXPIRES,
                                                    'field' => $_POST['pt_card_expiration'])));
    } else {
      $confirmation = array(); //array('title' => $this->title);
    }
  }

  /**
   * Build the data and actions to process when the "Submit" button is pressed on the order-confirmation screen.
   * This sends the data to the payment gateway for processing.
   * (These are hidden fields on the checkout confirmation page)
   *
   * @return string
   */
  function process_button() {
    global $order;

    $sid = 'ction=confirm&zenid=' . zen_session_id(); 

    $submit_data_core = array(
      'pt_gateway_account'       => MODULE_PAYMENT_PLUGNPAY_SS2_LOGIN,
      'pt_transaction_amount'    => round($order->info['total'], 2),
      'pt_currency_code'         => $_SESSION['currency'],
      'pb_port_auth'             => MODULE_PAYMENT_PLUGNPAY_SS2_AUTHORIZATION_TYPE == 'Authorize' ? 'no': 'yes',
      'pt_account_code_2'        => $_SESSION['customer_id'],
      'pt_billing_company'       => $order->billing['company'],
      'pt_payment_name'          => $order->billing['firstname'] . ' ' . $order->billing['lastname'],
      'pt_billing_address_1'     => $order->billing['street_address'],
      'pt_billing_city'          => $order->billing['city'],
      'pt_billing_state'         => $order->billing['state'],
      'pt_billing_postal_code'   => $order->billing['postcode'],
      'pt_billing_country'       => $order->billing['country']['iso_code_2'],
      'pt_billing_phone_number'  => $order->customer['telephone'],
      'pt_billing_fax_number'    => $order->customer['fax'],
      'pt_billing_email_address' => $order->customer['email_address'],
      'pt_client_identifier'     => 'ZenCart_SS2',
      'pt_ip_address'            => zen_get_ip_address(),
      'pb_transition_type'       => 'post',
      'pb_success_url'           => zen_href_link(FILENAME_CHECKOUT_PROCESS, $sid, 'SSL', true, false),
      'x_description'            => 'Website Purchase from ' . str_replace('"',"'", STORE_NAME)
    );


    $submit_data_ship = array(
      'pd_collect_shipping_information' => 'no',
    );
    if (0) {
      $submit_data_ship['pt_shipping_company']     = $order->delivery['company'];
      $submit_data_ship['pt_shipping_name']        = $order->delivery['firstname'] . ' ' . $order->delivery['lastname'];
      $submit_data_ship['pt_shipping_address_1']   = $order->delivery['street_address'];
      $submit_data_ship['pt_shipping_city']        = $order->delivery['city'];
      $submit_data_ship['pt_shipping_state']       = $order->delivery['state'];
      $submit_data_ship['pt_shipping_postal_code'] = $order->delivery['postcode'];
      $submit_data_ship['pt_shipping_country']     = $order->delivery['country']['iso_code_2'];
    }

    $submit_data_curr = array(
      'pt_currency' => $this->gateway_currency,
    );
    // force conversion to supported currencies: USD, GBP, CAD, EUR, AUD, NZD
    if ($order->info['currency'] != $this->gateway_currency) {
      global $currencies;
      $submit_data_curr['pt_transaction_amount'] = round($order->info['total'] * $currencies->get_value($this->gateway_currency), 2);
      $submit_data_curr['pt_currency'] = $this->gateway_currency;
      $submit_data_curr['x_description'] .= ' (Converted from: ' . number_format($order->info['total'] * $order->info['currency_value'], 2) . ' ' . $order->info['currency'] . ')';
    }

    $this->notify('NOTIFY_PAYMENT_PLUGNPAY_SS2_PRESUBMIT_HOOK');

    $submit_data = array_merge($submit_data_core, $submit_data_ship, $submit_data_curr);
    $submit_data[zen_session_name()] = zen_session_id();

    $process_button_string = "\n";
    foreach($submit_data as $key => $value) {
      $process_button_string .= zen_draw_hidden_field($key, $value) . "\n";
    }

    // prepare a copy of submitted data for error-reporting purposes
    $this->reportable_submit_data = $submit_data;
    $this->_debugActions($this->reportable_submit_data, 'Submit-Data', '', zen_session_id());

    return $process_button_string;
  }

  /**
   * Store the CC info to the order and process any results that come back from the payment gateway
   *
   */
  function before_process() {
    global $messageStack, $order, $_POST;

    $this->authorize = $_POST;
    unset($this->authorize['btn_submit_x'], $this->authorize['btn_submit_y']);

    $this->notify('NOTIFY_PAYMENT_PLUGNPAY_SS2_POSTSUBMIT_HOOK', $this->authorize);
    $this->_debugActions($this->authorize, 'Response-Data', '', zen_session_id());

    if ($this->authorize['pi_response_status'] == 'success') {
      $order->info['cc_type'] = $this->authorize['pt_card_type'];
      $order->info['cc_number'] = $this->authorize['pt_card_number'];
      $order->info['cc_owner'] = $this->authorize['pt_payment_name'];
      $this->auth_code = $this->authorize['pt_authorization_code'];
      $this->transaction_id = $this->authorize['pt_order_id'];
      return true;
    }
    if ($this->authorize['pi_response_status'] == 'badcard') {
      $messageStack->add_session('checkout_payment', $this->authorize['pi_error_message'] . MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_DECLINED_MESSAGE, 'error');
      zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL', true, false));
    }
    if ($this->authorize['pi_response_status'] == 'fraud') {
      $messageStack->add_session('checkout_payment', $this->authorize['pi_error_message'] . MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_DECLINED_MESSAGE, 'error');
      zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL', true, false));
    }
    // Code 3 or anything else is an error
    $messageStack->add_session('checkout_payment', MODULE_PAYMENT_PLUGNPAY_SS2_TEXT_ERROR_MESSAGE, 'error');
    zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL', true, false));
  }

  /**
   * Post-processing activities
   *
   * @return boolean
   */
  function after_process() {
    global $insert_id, $order, $currencies;
    $this->notify('NOTIFY_PAYMENT_PLUGNPAY_SS2_POSTPROCESS_HOOK');

    $comments = 'Credit Card payment.  AUTH: ' . $this->auth_code . ' TransID: ' . $this->transaction_id;
    if ($order->info['currency'] != $this->gateway_currency) {
      $comments .= ' (' . number_format($order->info['total'] * $currencies->get_value($this->gateway_currency), 2) . ' ' . $this->gateway_currency . ')';
    }
    zen_update_orders_history($insert_id, $comments, null, $this->order_status, -1);

    return false;
  }

  /**
   * Check to see whether module is installed
   *
   * @return boolean
   */
  function check() {
    global $db;
    if (!isset($this->_check)) {
      $check_query = $db->Execute("SELECT configuration_value FROM " . TABLE_CONFIGURATION . " WHERE configuration_key = 'MODULE_PAYMENT_PLUGNPAY_SS2_STATUS'");
      $this->_check = $check_query->RecordCount();
    }
    if ($this->_check > 0) $this->keys(); // install any missing keys
    return $this->_check;
  }

  /**
   * Install the payment module and its configuration settings
   *
   */
  function install() {
    global $db, $messageStack;
    if (defined('MODULE_PAYMENT_PLUGNPAY_SS2_STATUS')) {
      $messageStack->add_session('PlugnPay (SSv2) module already installed.', 'error');
      zen_redirect(zen_href_link(FILENAME_MODULES, 'set=payment&module=plugnpay_ss2', 'SSL', true, false));
      return 'failed';
    }
    $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) VALUES ('Enable PlugnPay Module', 'MODULE_PAYMENT_PLUGNPAY_SS2_STATUS', 'True', 'Do you want to accept PlugnPay payments?', '6', '0', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
    $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) VALUES ('Gateway Account', 'MODULE_PAYMENT_PLUGNPAY_SS2_LOGIN', 'testing', 'The Gateway Account login used for your PlugnPay account.', '6', '0', now())");
    $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) VALUES ('Authorization Type', 'MODULE_PAYMENT_PLUGNPAY_SS2_AUTHORIZATION_TYPE', 'Authorize', 'Do you want submitted credit card transactions to be authorized only, or captured immediately?', '6', '0', 'zen_cfg_select_option(array(\'Authorize\', \'Capture\'), ', now())");
    $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) VALUES ('Sort order of display.', 'MODULE_PAYMENT_PLUGNPAY_SS2_SORT_ORDER', '0', 'Sort order of displaying payment options to the customer. Lowest is displayed first.', '6', '0', now())");
    $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, use_function, set_function, date_added) VALUES ('Payment Zone', 'MODULE_PAYMENT_PLUGNPAY_SS2_ZONE', '0', 'If a zone is selected, only enable this payment method for that zone.', '6', '2', 'zen_get_zone_class_title', 'zen_cfg_pull_down_zone_classes(', now())");
    $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) VALUES ('Set Order Status', 'MODULE_PAYMENT_PLUGNPAY_SS2_ORDER_STATUS_ID', '2', 'Set the status of orders made with this payment module to this value', '6', '0', 'zen_cfg_pull_down_order_statuses(', 'zen_get_order_status_name', now())");
    $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) VALUES ('Enable Database Storage', 'MODULE_PAYMENT_PLUGNPAY_SS2_STORE_DATA', 'True', 'Do you want to save the gateway communications data to the database?', '6', '0', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
    $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) VALUES ('Currency Supported', 'MODULE_PAYMENT_PLUGNPAY_SS2_CURRENCY', 'USD', 'Which currency is your PlugnPay Gateway Account configured to accept?<br>(Purchases in any other currency will be pre-converted to this currency before submission using the exchange rates in your store admin.)', '6', '0', 'zen_cfg_select_option(array(\'USD\', \'CAD\', \'GBP\', \'EUR\', \'AUD\', \'NZD\'), ', now())");

    // Now do database-setup:
    global $db, $sniffer;
    if ($sniffer->table_exists(TABLE_PLUGNPAY))  {
      $db->Execute("DROP TABLE " . TABLE_PLUGNPAY);
    }
    $sql = "CREATE TABLE " . TABLE_PLUGNPAY . " (
      id int(25) unsigned NOT NULL auto_increment,
      customer_id varchar(30) NOT NULL default '',
      order_id varchar(30) NOT NULL default '',
      response_code varchar(5) NOT NULL default '',
      response_text varchar(255) NOT NULL default '',
      authorization_type varchar(25) NOT NULL default '',
      transaction_id varchar(255) NOT NULL default '',
      sent varchar(255) NOT NULL default '',
      received varchar(255) NOT NULL default '',
      time varchar(255) NOT NULL default '',
      session_id varchar(255) NOT NULL default '',
      PRIMARY KEY (id),
      KEY idx_customer_id_zen (customer_id)
    )";
    $db->Execute($sql);
    //$sql = "ALTER TABLE ".TABLE_ORDERS." ADD `purchaseOrderId` VARCHAR(200) NOT NULL";
    //$db->Execute($sql);
  }

  /**
   * Remove the module and all its settings
   *
   */
  function remove() {
    global $db, $sniffer;
    $db->Execute("DELETE FROM " . TABLE_CONFIGURATION . " WHERE configuration_key IN ('" . implode("', '", $this->keys()) . "')");
    // cleanup database if contains no data
    if ($sniffer->table_exists(TABLE_PLUGNPAY)) {
      $db->Execute("DROP TABLE " . TABLE_PLUGNPAY);
    }
  }

  /**
   * Internal list of configuration keys used for configuration of the module
   *
   * @return array
   */
  function keys() {
    if (defined('MODULE_PAYMENT_PLUGNPAY_SS2_STATUS')) {
      global $db;
      if (!defined('MODULE_PAYMENT_PLUGNPAY_SS2_CURRENCY')) {
        $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) VALUES ('Currency Supported', 'MODULE_PAYMENT_PLUGNPAY_SS2_CURRENCY', 'USD', 'Which currency is your PlugnPay Gateway Account configured to accept?<br>(Purchases in any other currency will be pre-converted to this currency before submission using the exchange rates in your store admin.)', '6', '0', 'zen_cfg_select_option(array(\'USD\', \'CAD\', \'GBP\', \'EUR\', \'AUD\', \'NZD\'), ', now())");
      }
      if (defined('MODULE_PAYMENT_PLUGNPAY_SS2_MD5HASH')) {
        // update description
        $db->Execute("DELETE FROM " . TABLE_CONFIGURATION . " WHERE configuration_key = 'MODULE_PAYMENT_PLUGNPAY_SS2_MD5HASH'");
      }
    }
    return array('MODULE_PAYMENT_PLUGNPAY_SS2_STATUS', 'MODULE_PAYMENT_PLUGNPAY_SS2_LOGIN', 'MODULE_PAYMENT_PLUGNPAY_SS2_CURRENCY', 'MODULE_PAYMENT_PLUGNPAY_SS2_AUTHORIZATION_TYPE', 'MODULE_PAYMENT_PLUGNPAY_SS2_ZONE', 'MODULE_PAYMENT_PLUGNPAY_SS2_ORDER_STATUS_ID', 'MODULE_PAYMENT_PLUGNPAY_SS2_SORT_ORDER', 'MODULE_PAYMENT_PLUGNPAY_SS2_STORE_DATA');
  }

  /**
   * Used to do any debug logging / tracking / storage as required.
   */
  function _debugActions($response, $mode, $order_time= '', $sessID = '') {
    global $db, $messageStack, $insert_id;
    if ($order_time == '') $order_time = date("F j, Y, g:i a");
    $response['url'] = $this->form_action_url;
    $this->reportable_submit_data['url'] = $this->form_action_url;

    $errorMessage = date('M-d-Y h:i:s') . "\n=================================\n\n";
    if ($mode == 'Submit-Data') $errorMessage .= 'Sent to PlugnPay: ' . print_r($this->reportable_submit_data, true) . "\n\n";
    if ($mode == 'Response-Data') $errorMessage .= 'Response Code: ' . $response['pi_response_status'] . ".\nResponse Text: " . $response['pi_error_message'] . "\n\n" . 'Results Received back from PlugnPay: ' . print_r($response, true) . "\n\n";

    // DATABASE SECTION
    // Insert the send and receive response data into the database.
    // This can be used for testing or for implementation in other applications
    // This can be turned on and off if the Admin Section
    if (MODULE_PAYMENT_PLUGNPAY_SS2_STORE_DATA == 'True' && $mode == 'Response-Data'){
      $db_response_text = $response['pi_error_message'];

      // Insert the data into the database
      $sql = "INSERT INTO " . TABLE_PLUGNPAY . "  (id, customer_id, order_id, response_code, response_text, authorization_type, transaction_id, sent, received, time, session_id) VALUES (NULL, :custID, :orderID, :respCode, :respText, :authType, :transID, :sentData, :recvData, :orderTime, :sessID )";
      $sql = $db->bindVars($sql, ':custID', $_SESSION['customer_id'], 'integer');
      $sql = $db->bindVars($sql, ':orderID', preg_replace('/[^0-9]/', '', $insert_id), 'integer');
      $sql = $db->bindVars($sql, ':respCode', $response['pi_response_status'], 'integer');
      $sql = $db->bindVars($sql, ':respText', $db_response_text, 'string');
      $sql = $db->bindVars($sql, ':authType', $response['pt_card_type'], 'string');
      if (isset($response['pt_order_id']) && trim($response['pt_order_id']) != '') {
        $sql = $db->bindVars($sql, ':transID', $response['pt_order_id'], 'string');
      } else {
        $sql = $db->bindVars($sql, ':transID', 'NULL', 'passthru');
      }
      $sql = $db->bindVars($sql, ':sentData', print_r($this->reportable_submit_data, true), 'string');
      $sql = $db->bindVars($sql, ':recvData', print_r($response, true), 'string');
      $sql = $db->bindVars($sql, ':orderTime', $order_time, 'string');
      $sql = $db->bindVars($sql, ':sessID', $sessID, 'string');
      $db->Execute($sql);
    }
  }

  /**
   * Check and fix table structure if appropriate
   */
  function tableCheckup() {
    global $db, $sniffer;
    /*
      $fieldOkay1 = (method_exists($sniffer, 'field_type')) ? $sniffer->field_type(TABLE_PLUGNPAY, 'transaction_id', 'varchar(64)', true) : -1;
      if ($fieldOkay1 !== true) {
        $db->Execute("ALTER TABLE " . TABLE_PLUGNPAY . " CHANGE transaction_id transaction_id varchar(64) default NULL");
      }
    */
  }
}

