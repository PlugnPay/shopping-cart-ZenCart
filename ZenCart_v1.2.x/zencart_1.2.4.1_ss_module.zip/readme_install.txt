=================================================
Plug 'n Pay - Smart Screens Method
Payment Module for ZenCart v1.2.4 
=================================================

***** IMPORTANT NOTES *****
This module is being provided "AS IS".  Limited technical support assistance will
be given to help diagnose/address problems with this module.  The amount of support
provided is up to PlugnPay's staff.

It is recommended if you experience a problem with this module, first seek assistance
through this module's readme file, then check with the ZenCart community at
'www.zencart.com', and if you are still unable to resolve the issue, contact us
via PlugnPay's Online Helpdesk.

This module is used without having your own server's SSL abilities. We will ask the
customer for all of their credit card info on our SSL secured billing page on our
secured servers.  The authorization will be done via PlugnPay's Smart Screens payment
method.  The module is intended to itemize the order in the PlugnPay system using
available information from the cart.

If you want to change the behavior of this module, please feel free to make changes
to the files yourself.  However, customized ZenCart modules will not be provided
support assistance.

In addition, you should have the 'Enable secure SSL/HTTPS connections' option disabled
in your ZenCart shopping cart to properly use this module. If you have your own SSL
security certificate, download/use the Direct Method version of this module instead.
***************************

Installation:

For a default ZenCart installation, simply upload the provided files into
the 'catalog' folder and activate in the ZenCart admin area.

For a custom ZenCart installation, change all refferences of 'catalog' in
the module's .php scripts to the folder name where you actually installed the
shopping cart to.  Then upload the modified module to your custom folder where
you installed ZenCart to.


If you run into problems:

Check to be sure you actually uploaded the files in the correct folder.

Check the uploaded file's permissions:
-- .php files should be chmod 755
   (read/write/execute by owner, read/execute by all others)
-- .gif files should be chmod 644
   (read/write by owner, read only by all others)

If you allow online electronic check payments, you must be sure you have an electronic
checking account setup with PlugnPay prior to accepting online check payments through
ZenCart.

These are the common issues found by our support staff.


Some Processing Errors could include:

Invalid Method:

This module requires all Plug 'n Pay clients to use a POST method back to their site.
If you have a problem with the connection made from our gateway back to your shopping
cart, please contact our technical support staff via the online helpdesk & request we
switch your account from a GET (transition page) to the POST method for your connection
back to your site.

Un-Authorized Purchase:

This means the IP address that is connecting to your 'order_process_plugnpay.php'
script is not from our server network.  It is likely someone is trying to trick your
shopping cart into believing an order is successful when it was not authorized through
our payment gateway.

Declined or Problem Purchase:

This means the order was not approved via our gateway.  It is likely someone is trying
to trick your shopping cart into believing an order is successful when it was not
authorized through our gateway successfully.

-----------------------------------------------------------------------------
Updates:

05/04/05
- converted PnP's osCommerce v2.2 Smart Screen module to work with ZenCart v1.2.4.1
- removed need for replacing the modules.php file in the admin folder

05/07/05
- cleaned up code to make it more readable and efficent 
- fixed credit card icons, so they will now show correctly on billing page

01/18/06
- adjusted code to use the new 'pay.cgi' shared payment script, instead of using the
  old 'usernamepay.cgi' payment script.

08/08/06
- fixed typo in 'REQUEST_METHOD' line of the order_process_plugnpay.php script.

