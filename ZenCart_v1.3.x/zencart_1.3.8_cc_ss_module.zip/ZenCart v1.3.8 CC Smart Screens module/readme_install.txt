=================================================
PlugnPay CC Smart Screens Method
Payment Module for ZenCart v1.3.8
=================================================

***** IMPORTANT NOTES *****
This module is being provided "AS IS".  Limited technical support assistance will
be given to help diagnose/address problems with this module.  The amount of support
provided is up to PlugnPay's staff.

If you experience a problem with this module, first seek assistance through this
module's readme file, then check with the community at 'www.zencart.com'.
If you are still unable to resolve the issue, contact us via PlugnPay's Online Helpdesk.

This module is used without having your own server's SSL abilities. We will ask the
customer for all of their credit card info on our SSL secured billing page on our
secured servers.  The authorization will be done via PlugnPay's Smart Screens payment
method.  The module is intended to itemize the order in the PlugnPay system using
available information from the cart.

If you want to change the behavior of this module, please feel free to make changes
to the files yourself.  However, customized payment modules will not be provided
support assistance.
***************************

Installation:

1. Copy the zencart_root/images/icons folder & its related icon images into to the
corresponding images folder within your shopping cart folder on your web server.

2. Copy the zencart_root/includes/languages/english/modules/payment/plugnpay_cc_ss.php
file to the corresponding place within your shopping cart folder on your web server.

3. Do the same with zencart_root/includes/modules/payment/plugnpay_cc_ss.php

4. Go into your admin panel and activate the PlugnPay payment module on the payment modules
page and fill in the appropriate data.

5. Go into the Account Settings section of your PlugnPay administration area.
Enable the Use Transition Page option & set the Transition Page Type to
'post'.


Troubleshooting:

Check to be sure you actually uploaded the files in the correct folders;
ensuring you overwrite the existing file, if one exists.

Check the uploaded file's permissions:
-- .gif files should be chmod 644
   (read/write by owner, read only by all others)
-- .php files should be chmod 755
   (read/write/execute by owner, read/execute by all others)

Make sure you have an active merchant account for a given card type, prior to accepting
online payments for it.  This is very important for Amex & Discover cards. 

These are the common issues found by our support staff.

-----------------------------------------------------------------------------
Updates:

12/27/08
- created basic PlugnPay Credit Card Smart Screens payment module.

12/30/08
- consolidated code base, to make it more user friendly.
- applied minor bug fixes.

01/03/09
- applied minor bug fixes.
- adjusted module installation instructions
- corrected card-type option display in admin area & during checkout process.
- changed module send 2-char country ISO code, instead of country name.

01/19/09
- applied minor bug fixes
- reduced the module's code base
- streamlined the order finalization process

01/24/09
- applied minor bug fixes
- added checkbox selection for allowed card types
- added card type icons during checkout
- applied updates to installation instructions
- cleaned up 'plugnpay_cc_ss.php' language file
- cleaned up 'plugnpay_cc_ss.php' payment code

