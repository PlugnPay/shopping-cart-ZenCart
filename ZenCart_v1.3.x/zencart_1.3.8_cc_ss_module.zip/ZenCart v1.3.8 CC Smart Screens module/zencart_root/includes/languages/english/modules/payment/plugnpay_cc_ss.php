<?php
/**
 * PlugnPay CC Smart Screens Payment Module
 *
 * @package languageDefines
 * @copyright Copyright 2003-2007 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: plugnpay_cc_ss.php 6641 2009-01-13 12:00:00Z drbyte $
 */

  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_TEXT_ADMIN_TITLE', 'PlugnPay Credit Card SS');
  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_TEXT_CATALOG_TITLE', 'Credit Card (Processed by PlugnPay)');  // Payment option title as displayed to the customer

  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_TEXT_DESCRIPTION', 'PlugnPay Smart Screens<br>Credit Card<br>&nbsp;<br><img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.plugnpay.com" target="_blank" style="text-decoration: underline; font-weight: bold;">Visit PlugnPay.com Website</a>');

  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_TEXT_ERROR', 'Credit Card Error!');
  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_ERROR_VERIFICATION', 'The credit card transaction could not be verified with this order. Please try again and if problems persist, please try another payment method.');
  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_ERROR_BADCARD', 'This credit card transaction has been declined. Please try again and if problems persist, please try another payment method.');
  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_ERROR_PROBLEM', 'There was a problem processing your credit card transaction. Please try again and if problems persist, please try another payment method.');
  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_ERROR_FRAUD', 'This credit card transaction has been rejected. Please try again and if problems persist, please try another payment method.');
  define('MODULE_PAYMENT_PLUGNPAY_CC_SS_ERROR_GENERAL', 'Please try again and if problems persist, please try another payment method.');

?>
