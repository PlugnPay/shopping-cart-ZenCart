<?php
/**
 * member_validation Class.
 *
 * @package classes
 * @copyright Copyright 2003-2007 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: member_validation.php 7379 2007-11-08 03:58:07Z drbyte $
 */
if (!defined('IS_ADMIN_FLAG')) {
  die('Illegal Access');
}
/**
 * member_validation Class.
 * Class to validate member username & password
 *
 * @package classes
 */
class member_validation extends base {
  var $member_username, $member_password;

    function validate($username, $password) {

    if (($username != "") && (strlen($username) >= 4)) {
      $this->member_username = $username;
    } else {
      return -1;
    }

    if (($password != "") && (strlen($password) >= 4)) {
      $this->member_password = $password;
    } else {
      return -2;
    }

    return true;
  }
}
?>
