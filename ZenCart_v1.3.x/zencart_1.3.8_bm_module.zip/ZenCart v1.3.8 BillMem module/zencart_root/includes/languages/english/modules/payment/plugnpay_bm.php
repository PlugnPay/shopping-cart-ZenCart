<?php
/**
 * PlugnPay BM Module Version 0.2
 *
 * @package paymentMethod
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: plugnpay_arb.php 5436 2008-12-04 19:09:50Z AphelionZ $
 */
/*
#######################################################################
# Original module written by Mark Henderson (henderson.mark@gmail.com)
# Modified by PlugnPay for use with our payment gateway services.
#######################################################################
*/

// Admin section
  define('MODULE_PAYMENT_PLUGNPAY_BM_TEXT_ADMIN_TITLE', 'PlugnPay BM');
  define('MODULE_PAYMENT_PLUGNPAY_BM_TEXT_DESCRIPTION', 'PlugnPay Bill Member');

// Form field labels
  define('MODULE_PAYMENT_PLUGNPAY_BM_TEXT_CATALOG_TITLE', 'Bill Using Membership Data');
  // ^^ Payment option title as displayed to the customer in checkout ^^
  define('MODULE_PAYMENT_PLUGNPAY_BM_TEXT_MEMBER_USERNAME', 'Member Username:');
  define('MODULE_PAYMENT_PLUGNPAY_BM_TEXT_MEMBER_PASSWORD', 'Member Password:');

  define('MODULE_PAYMENT_PLUGNPAY_BM_TEXT_USERNAME', 'Username:');
  define('MODULE_PAYMENT_PLUGNPAY_BM_TEXT_PASSWORD', 'Password:');


// JS error messages
  define('MODULE_PAYMENT_PLUGNPAY_BM_TEXT_JS_MEMBER_USERNAME', '* The member username provided must be at least 4 characters.\n');
  define('MODULE_PAYMENT_PLUGNPAY_BM_TEXT_JS_MEMBER_PASSWORD', '* The member password provided must be at least 4 characters.\n');
  
// Other error messages
  define('MODULE_PAYMENT_PLUGNPAY_BM_TEXT_ERROR_INVALID_USERNAME', 'Invalid Member Username');
  define('MODULE_PAYMENT_PLUGNPAY_BM_TEXT_ERROR_INVALID_PASSWORD', 'Invalid Member Password');
  define('MODULE_PAYMENT_PLUGNPAY_BM_TEXT_ERROR_INVALID_LOGIN', 'Invalid Login Info');

  define('MODULE_PAYMENT_PLUGNPAY_BM_TEXT_DECLINED_MESSAGE', 'There has been an error processing your payment. Please try again.');
  /*define('MODULE_PAYMENT_PLUGNPAY_TEXT_GATEWAY_TIMEOUT', 'There was an error contacting the payment processor. Please try again.');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_ERROR', 'There was a problem processing your payment! Not-Approved.');
  define('MODULE_PAYMENT_PLUGNPAY_TEXT_WRONG_TYPE', 'The payment does not match the given type.');
  */
  
?>
