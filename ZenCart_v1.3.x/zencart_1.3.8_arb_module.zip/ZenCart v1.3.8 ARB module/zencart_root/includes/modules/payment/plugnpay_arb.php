<?php
/**
 * PlugnPay ARB Module Version 0.2
 *
 * @package paymentMethod
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: plugnpay_arb.php 5436 2008-12-04 19:09:50Z AphelionZ $
 */
/*
#######################################################################
# Original module written by Mark Henderson (henderson.mark@gmail.com)
# Modified by PlugnPay for use with our payment gateway services.
#######################################################################
*/

class plugnpay_arb {
  var $code, $title, $enabled, $response;

  function substring_between($haystack,$start,$end) {
    if (strpos($haystack,$start) === false || strpos($haystack,$end) === false) {
      return false;
    } 
    else {
      $start_position = strpos($haystack,$start)+strlen($start);
      $end_position = strpos($haystack,$end);
      return substr($haystack,$start_position,$end_position-$start_position);
    }
  }

  function plugnpay_arb() {
    global $order;
    $this->code = 'plugnpay_arb';

    if (IS_ADMIN_FLAG === true) {
      $this->title = MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_ADMIN_TITLE; // Payment module title in Catalog
      if (MODULE_PAYMENT_PLUGNPAY_ARB_STATUS == 'True' && (MODULE_PAYMENT_PLUGNPAY_ARB_LOGIN == 'testing' || MODULE_PAYMENT_PLUGNPAY_ARB_PASSWD == 'Test')) {
        $this->title .=  '<span class="alert"> (Not Configured)</span>'; 
      }
      else if (MODULE_PAYMENT_PLUGNPAY_ARB_TESTMODE == 'Test') {
        $this->title .= '<span class="alert"> (in Testing mode)</span>';
      }
    }
    else {
      $this->title = MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CATALOG_TITLE; // Payment module title in Admin
    }
                
    $this->description = MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_DESCRIPTION;
    // Descriptive Info about module in Admin

    $this->enabled = ((MODULE_PAYMENT_PLUGNPAY_ARB_STATUS == 'True') ? true : false);
    // Whether the module is installed or not

    $this->sort_order = MODULE_PAYMENT_PLUGNPAY_ARB_SORT_ORDER;
    // Sort Order of this payment option on the customer payment page

    $this->form_action_url = zen_href_link(FILENAME_CHECKOUT_PROCESS, '', 'SSL', false);
    // Page to go to upon submitting page info
                
    if ((int)MODULE_PAYMENT_PLUGNPAY_ARB_ORDER_STATUS_ID > 0) {
      $this->order_status = MODULE_PAYMENT_PLUGNPAY_ARB_ORDER_STATUS_ID;
    }
                
    if (is_object($order)) {
      $this->update_status();
    }
  }
  // End Constructor

  /**
  * calculate zone matches and flag settings to determine whether this module should display to customers or not
  *
  */
  function update_status() {
    global $order, $db;

    if (($this->enabled == true) && ((int)MODULE_PAYMENT_PLUGNPAY_ARB_ZONE > 0)) {
      $check_flag = false;
      $check = $db->Execute("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_PLUGNPAY_ARB_ZONE . "' and zone_country_id = '" . $order->billing['country']['id'] . "' order by zone_id");
      while (!$check->EOF) {
        if ($check->fields['zone_id'] < 1) {
          $check_flag = true;
          break;
        }
        else if ($check->fields['zone_id'] == $order->billing['zone_id']) {
          $check_flag = true;
          break;
        }
        $check->MoveNext();
      }

      if ($check_flag == false) {
        $this->enabled = false;
      }
    }
  }
        
  /**
  * JS validation which does error-checking of data-entry if this module is selected for use
  * (Number, Owner, and CVV Lengths)
  *
  * @return string
  */
  function javascript_validation() {
    $js = '  if (payment_value == "' . $this->code . '") {' . "\n" .
          '    var cc_owner = document.checkout_payment.plugnpay_arb_cc_owner.value;' . "\n" .
          '    var cc_number = document.checkout_payment.plugnpay_arb_cc_number.value;' . "\n";
    if (MODULE_PAYMENT_PLUGNPAY_ARB_USE_CVV == 'True')  {
      $js .= '    var cc_cvv = document.checkout_payment.plugnpay_arb_cc_cvv.value;' . "\n";
    }
    $js .= '    if (cc_owner == "" || cc_owner.length < ' . CC_OWNER_MIN_LENGTH . ') {' . "\n" .
           '      error_message = error_message + "' . MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_JS_CC_OWNER . '";' . "\n" .
           '      error = 1;' . "\n" .
           '    }' . "\n" .
           '    if (cc_number == "" || cc_number.length < ' . CC_NUMBER_MIN_LENGTH . ') {' . "\n" .
           '      error_message = error_message + "' . MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_JS_CC_NUMBER . '";' . "\n" .
           '      error = 1;' . "\n" .
           '    }' . "\n";
    if (MODULE_PAYMENT_PLUGNPAY_ARB_USE_CVV == 'True')  {
      $js .= '    if (cc_cvv == "" || cc_cvv.length < "3" || cc_cvv.length > "4") {' . "\n".
             '      error_message = error_message + "' . MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_JS_CC_CVV . '";' . "\n" .
             '      error = 1;' . "\n" .
             '    }' . "\n" ;
    }
    $js .= '  }' . "\n";

    return $js;
  }
        
  /**
  * Display Credit Card Information Submission Fields on the Checkout Payment Page
  *
  * @return array
  */
  function selection() {
    global $order;

    for ($i=1; $i<13; $i++) {
      $expires_month[] = array('id' => sprintf('%02d', $i), 'text' => strftime('%B',mktime(0,0,0,$i,1,2000)));
    }

    $today = getdate();
    for ($i=$today['year']; $i < $today['year']+10; $i++) {
      $expires_year[] = array('id' => strftime('%y',mktime(0,0,0,1,1,$i)), 'text' => strftime('%Y',mktime(0,0,0,1,1,$i)));
    }
    $onFocus = ' onfocus="methodSelect(\'pmt-' . $this->code . '\')"';

    if (MODULE_PAYMENT_PLUGNPAY_ARB_USE_CVV == 'True') {
      $selection = array('id' => $this->code,
                         'module' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CATALOG_TITLE,
                         'fields' => array(array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CREDIT_CARD_OWNER,
                                                 'field' => zen_draw_input_field('plugnpay_arb_cc_owner', $order->billing['firstname'] . ' ' . $order->billing['lastname'],
                                                 'id="'.$this->code.'-cc-owner"'. $onFocus),
                                                 'tag' => $this->code.'-cc-owner'),
                                           array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CREDIT_CARD_NUMBER,
                                                 'field' => zen_draw_input_field('plugnpay_arb_cc_number', '',
                                                 'id="'.$this->code.'-cc-number"' . $onFocus),
                                                 'tag' => $this->code.'-cc-number'),
                                           array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CREDIT_CARD_EXPIRES,
                                                 'field' => zen_draw_pull_down_menu('plugnpay_arb_cc_expires_month', $expires_month, '',
                                                 'id="'.$this->code.'-cc-expires-month"' . $onFocus) . '&nbsp;' . zen_draw_pull_down_menu('plugnpay_arb_cc_expires_year', $expires_year, '',
                                                 'id="'.$this->code.'-cc-expires-year"' . $onFocus),
                                                 'tag' => $this->code.'-cc-expires-month'),
                                           array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CVV,
                                                 'field' => zen_draw_input_field('plugnpay_arb_cc_cvv','', 'size="4", maxlength="4"' . ' id="'.$this->code.'-cc-cvv"' . $onFocus) . ' ' . '<a href="javascript:popupWindow(\'' . zen_href_link(FILENAME_POPUP_CVV_HELP) . '\')">' . MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_POPUP_CVV_LINK . '</a>',
                                                 'tag' => $this->code.'-cc-cvv')));
    }
    else {
      $selection = array('id' => $this->code,
                         'module' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CATALOG_TITLE,
                         'fields' => array(array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CREDIT_CARD_OWNER,
                                                 'field' => zen_draw_input_field('plugnpay_arb_cc_owner', $order->billing['firstname'] . ' ' . $order->billing['lastname'],
                                                 'id="'.$this->code.'-cc-owner"'. $onFocus),
                                                 'tag' => $this->code.'-cc-owner'),
                                           array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CREDIT_CARD_NUMBER,
                                                 'field' => zen_draw_input_field('plugnpay_arb_cc_number', '',
                                                 'id="'.$this->code.'-cc-number"' . $onFocus),
                                                 'tag' => $this->code.'-cc-number'),
                                           array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CREDIT_CARD_EXPIRES,
                                                 'field' => zen_draw_pull_down_menu('plugnpay_arb_cc_expires_month', $expires_month, '',                                      'id="'.$this->code.'-cc-expires-month"' . $onFocus) . '&nbsp;' . zen_draw_pull_down_menu('plugnpay_arb_cc_expires_year', $expires_year, '',
                                                 'id="'.$this->code.'-cc-expires-year"' . $onFocus),
                                                 'tag' => $this->code.'-cc-expires-month')));
    }
    return $selection;
  }

  /**
  * Evaluates the Credit Card Type for acceptance and the validity of the Credit Card Number & Expiration Date
  *
  */
  function pre_confirmation_check() {
    global $db, $_POST, $messageStack;
    include(DIR_WS_CLASSES . 'cc_validation.php');

    $cc_validation = new cc_validation();
    $result = $cc_validation->validate($_POST['plugnpay_arb_cc_number'], $_POST['plugnpay_arb_cc_expires_month'], $_POST['plugnpay_arb_cc_expires_year'], $_POST['plugnpay_arb_cc_cvv']);
    $error = '';
    switch ($result) {
      case -1:
        $error = sprintf(TEXT_CCVAL_ERROR_UNKNOWN_CARD, substr($cc_validation->cc_number, 0, 4));
        break;
      case -2:
      case -3:
      case -4:
        $error = TEXT_CCVAL_ERROR_INVALID_DATE;
        break;
      case false:
        $error = TEXT_CCVAL_ERROR_INVALID_NUMBER;
        break;
    }

    if (($result == false) || ($result < 1)) {
      $payment_error_return = 'payment_error=' . $this->code . '&plugnpay_arb_cc_owner=' . urlencode($_POST['plugnpay_arb_cc_owner']) . '&plugnpay_arb_cc_expires_month=' . $_POST['plugnpay_arb_cc_expires_month'] . '&plugnpay_arb_cc_expires_year=' . $_POST['plugnpay_arb_cc_expires_year'];
      $messageStack->add_session('checkout_payment', $error . '<!-- ['.$this->code.'] -->', 'error');
      zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, $payment_error_return, 'SSL', true, false));
    }

    $this->cc_card_type = $cc_validation->cc_type;
    $this->cc_card_number = $cc_validation->cc_number;
    $this->cc_expiry_month = $cc_validation->cc_expiry_month;
    $this->cc_expiry_year = $cc_validation->cc_expiry_year;
  }
        
  /**
  * Display Credit Card Information on the Checkout Confirmation Page
  *
  * @return array
  */
  function confirmation() {
    global $_POST;

    if (MODULE_PAYMENT_PLUGNPAY_ARB_USE_CVV == 'True') {
      $confirmation = array(//'title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CATALOG_TITLE, // Redundant
                            'fields' => array(array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CREDIT_CARD_TYPE,
                                                    'field' => $this->cc_card_type),
                                              array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CREDIT_CARD_OWNER,
                                                    'field' => $_POST['plugnpay_arb_cc_owner']),
                                              array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CREDIT_CARD_NUMBER,
                                                    'field' => substr($this->cc_card_number, 0, 4) . str_repeat('X', (strlen($this->cc_card_number) - 8)) . substr($this->cc_card_number, -4)),
                                              array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CREDIT_CARD_EXPIRES,
                                                    'field' => strftime('%B, %Y', mktime(0,0,0,$_POST['plugnpay_arb_cc_expires_month'], 1, '20' . $_POST['plugnpay_arb_cc_expires_year']))),
                                              array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CVV,
                                                    'field' => $_POST['plugnpay_arb_cc_cvv'])));
    }
    else {
      $confirmation = array(//'title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CATALOG_TITLE, // Redundant
                            'fields' => array(array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CREDIT_CARD_TYPE,
                                                    'field' => $this->cc_card_type),
                                              array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CREDIT_CARD_OWNER,
                                                    'field' => $_POST['plugnpay_arb_cc_owner']),
                                              array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CREDIT_CARD_NUMBER,
                                                    'field' => substr($this->cc_card_number, 0, 4) . str_repeat('X', (strlen($this->cc_card_number) - 8)) . substr($this->cc_card_number, -4)),
                                              array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_CREDIT_CARD_EXPIRES,
                                                    'field' => strftime('%B, %Y', mktime(0,0,0,$_POST['plugnpay_arb_cc_expires_month'], 1, '20' . $_POST['plugnpay_arb_cc_expires_year'])))));
    }
    return $confirmation;
  }
        
  function process_button() {
    $process_button_string = zen_draw_hidden_field('cc_owner', $_POST['plugnpay_arb_cc_owner']) .
    zen_draw_hidden_field('cc_expires', $this->cc_expiry_month . substr($this->cc_expiry_year, -2)) .
    zen_draw_hidden_field('cc_type', $this->cc_card_type) .
    zen_draw_hidden_field('cc_number', $this->cc_card_number);
    if (MODULE_PAYMENT_PLUGNPAY_ARB_USE_CVV == 'True') {
      $process_button_string .= zen_draw_hidden_field('cc_cvv', $_POST['plugnpay_arb_cc_cvv']);
    }

    $process_button_string .= zen_draw_hidden_field(zen_session_name(), zen_session_id());

    return $process_button_string;
    return false;
  }

  function before_process() {
    global $_POST, $response, $db, $order, $messageStack;

    // how many CC digits do we remember?
    if (MODULE_PAYMENT_PLUGNPAY_ARB_STORE_NUMBER == 'True') {
      $order->info['cc_number'] = $_POST['cc_number'];
    }
    else {
      $order->info['cc_number'] = str_pad(substr($_POST['cc_number'], -4), strlen($_POST['cc_number']), "X", STR_PAD_LEFT);
    }
    $order->info['cc_expires'] = $_POST['cc_expires'];
    $order->info['cc_type'] = $_POST['cc_type'];
    $order->info['cc_owner'] = $_POST['cc_owner'];
    $order->info['cc_cvv'] = $_POST['cc_cvv'];

    // DATA PREPARATION SECTION
    unset($submit_data);  // Cleans out any previous data stored in the variable

    // Create variable that holds the order's date (i.e. initial sign-up payment date)
    $startDate = date("Ymd"); 

    // Create varable that hold the order's next payment date (i.e. 1st recur billing payment date)
    $endDate = date("Ymd", time() + (MODULE_PAYMENT_PLUGNPAY_ARB_BILLCYCLE * 2629743.83));
    # NOTE: the endate should = the current_time + (billing_cycle * #_of_seconds_in_a_month) 

    // Calculate the next expected order id
    $last_order_id = $db->Execute("select * from " . TABLE_ORDERS . " order by orders_id desc limit 1");
    $new_order_id = $last_order_id->fields['orders_id'];
    $new_order_id = ($new_order_id + 1);


    // Do some initializing & sanity checks here
    $total_occurrences = MODULE_PAYMENT_PLUGNPAY_ARB_TOTAL_OCCURRENCES;
    $trial_discount = MODULE_PAYMENT_PLUGNPAY_ARB_TRIAL_DISCOUNT;
    $billcycle = MODULE_PAYMENT_PLUGNPAY_ARB_BILLCYCLE;

    if (MODULE_PAYMENT_PLUGNPAY_ARB_TOTAL_OCCURRENCES < 1) {
      # don't allow total occurences to be less then 1
      $total_occurrences = 1;
    }
    else {
      # when positive number is defined, ensure total occurences is a whole number
      $total_occurrences = number_format(MODULE_PAYMENT_PLUGNPAY_ARB_TOTAL_OCCURRENCES, 0);
    }

    if (MODULE_PAYMENT_PLUGNPAY_ARB_TRIAL_DISCOUNT < 0) {
      # don't allow trial discounts to be a negative number
      $trial_discount = 0;
    }

    if (MODULE_PAYMENT_PLUGNPAY_ARB_BILLCYCLE < 1) {
      # don't allow billcycle to be set lower then 1 (i.e. monthly recurring)
      $billcycle = 1;
    }

    // Calculate PnP recurring totals & other related settings
    $amount = $order->info['total'];  # grab total of order

    # initialize some stuff here
    $recfee = 0;
    $balance = 0;
    $trialAmount = 0;

    if ($trial_discount == "full") {
      # no initial charge.
      $trialAmount = 0;
      # set order total as balance
      $balance = $amount;
      # pay balance in equal recurring payments.
      $recfee = $balance / $total_occurrences;
    }
    else if ($trial_discount > 0) {
      # discount initial charge.
      $per_payment = $amount / ($total_occurrences + 1);
      $trialAmount = $per_payment - $trial_discount;
      # set remainder as balance
      $balance = $amount - $trialAmount;
      # pay balance in equal recurring payments.
      $recfee = $balance / $total_occurrences;
    }
    else {
      # assume all payments equal (including initial payment) 
      $per_payment = $amount / ($total_occurrences + 1);
      $trialAmount = $per_payment;
      $balance = $amount - $trialAmount;
      $recfee = $per_payment;
    }

    ## * NOTE: At this point, with the sanity checks, there should be at least 1 recurring payment necessary.
    if ($balance <= 0) {
      # this error should never happen, if the logic above is correct & all settings are properly santised.
      zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, 'error_message=' . urlencode("ERROR: ARB Payment cannot be processed -- Balance appears to be 0.00."), 'SSL', true, false));
      exit;
    }

    $expMonth = substr($_POST['cc_expires'], 0, 2);
    $expYear = substr($_POST['cc_expires'], 2, 4);

    $billingState = zen_get_zone_code($order->billing['country']['id'],$order->billing['zone_id'],0);
    $deliveryState = zen_get_zone_code($order->delivery['country']['id'],$order->delivery['zone_id'],0);

    // Populate an array that contains all of the data to be sent to PlugnPay
    $submit_data = array(
      'publisher_name' => MODULE_PAYMENT_PLUGNPAY_ARB_LOGIN,
      'publisher_password' => MODULE_PAYMENT_PLUGNPAY_ARB_PASSWD,
      'publisher_email' => MODULE_PAYMENT_PLUGNPAY_ARB_PUBEMAIL,
      'notify_email' => MODULE_PAYMENT_PLUGNPAY_ARB_PUBEMAIL,
      'client' => 'ZenCart_ARB',
      'mode' => 'auth|add_member',
      'convert' => 'underscores',
      'easycart' => '1',
      'shipinfo' => '1',
      'paymethod' => 'credit',
      //misc settings
      'authtype' => MODULE_PAYMENT_PLUGNPAY_ARB_AUTHTYPE == 'authonly' ? 'authonly': 'authpostauth',
      'dontsndmail' => MODULE_PAYMENT_PLUGNPAY_ARB_EMAILCUST == 'yes' ? 'yes': 'no',
      'order_id' => date("Ymd") .'-'. $new_order_id,
      'ipaddress' => $_SERVER['REMOTE_ADDR'],
      // order totals & other recurring settings
      'username' => 'zen' . date("Ymd") .'-'. $new_order_id,
      'purchaseid' => date("Ymd") .'-'. $new_order_id,
      'card_amount' => number_format($trialAmount,2), // initial charge
      'recfee' => number_format($recfee,2),           // recurring fee
      'balance' => number_format($balance,2),         // remaining balance
      'billcycle' => $billcycle,
      'startdate' => $startDate,
      'enddate' => $endDate,
      'total_occurrences' => $total_occurrences,
      // credit card info
      'card_number' => $_POST['cc_number'],
      'card_exp' => $expMonth.'/'.$expYear,
      'card_cvv' => $_POST['cc_cvv'],
      // billing address info
      'card_name' => $order->billing['firstname'] . ' ' . $order->billing['lastname'],
      'card_company' => $order->billing['company'],
      'card_address1' => $order->billing['street_address'],
      'card_address2' => $order->billing['street_address2'],
      'card_city' => $order->billing['city'],
      'card_state' => $billingState, // was $order->billing['state'],
      'card_zip' => $order->billing['postcode'],
      'card_country' => $order->billing['country']['title'],
      // instant contact info
      'phone' => $order->customer['telephone'],
      'email' => $order->customer['email_address'],
      // shipping address info
      'shipname' => $order->delivery['firstname'] . ' ' .$order->delivery['lastname'],
      'address1' => $order->delivery['street_address'],
      'address2' => $order->delivery['street_address2'],
      'city' => $order->delivery['city'],
      'state' => $deliveryState, // was $order->delivery['state'],
      'zip' => $order->delivery['postcode'],
      'country' => $order->delivery['country']['title'],
      // zencart specific details
      'zen_total' => number_format($order->info['total'], 2), // order's grand total
      'zen_customer_id' => $_SESSION['customer_id'],
      'zen_order_date' => $order_time,
      'zen_session_id' => zen_session_id()
    );
  
    // adjust mode, when no fee at time of sign-up.
    if ($trialAmount <= 0) {
      $submit_data["mode"] = 'checkcard|add_member'; // do 'checkcard', instead of an 'auth'
      $submit_data["card_amount"] = ''; // clear card-amount (so it uses default checkcard amount)
    }

    // itemize products being purchased
    for ($i = 0, $n = sizeof($order->products); $i < $n; $i++) {
      $j = $i + 1;
      $submit_data["item$j"] = $order->products[$i]['model'];
      $submit_data["cost$j"] = number_format($order->products[$i]['final_price'],2);
      $submit_data["quantity$j"] = $order->products[$i]['qty'];
      $submit_data["description$j"] = strip_tags($order->products[$i]['name']);
      $pnp_tax += ($order->products[$i]['final_price'] * $order->products[$i]['qty']) * ($order->products[$i]['tax'] / 100);
    }

    // set tax/shipping fees
    $submit_data["shipping"] = number_format($order->info['shipping_cost'],2);
    $submit_data["tax"] = number_format($pnp_tax,2);

    // flag when zencart is in test mode
    if(MODULE_PAYMENT_PLUGNPAY_ARB_TESTMODE == 'Test') {
      $submit_data['zen_status'] = 'debug';
    }

    // concatenate the submission data and put into $data variable
    while(list($key, $value) = each($submit_data)) {
      $data .= $key . '=' . urlencode(ereg_replace(',', '', $value)) . '&';
    }

    // Remove the last "&" from the string
    $data = substr($data, 0, -1);

    if (MODULE_PAYMENT_PLUGNPAY_ARB_TESTMODE == 'Test') {
      $filename = './plugnpay_debug.txt';
      $fp = fopen($filename, "a");
      $write = fputs($fp, "PREAUTH: $data\n");
      fclose($fp);
    }

    // SEND DATA BY CURL SECTION
    // Post order info data to PlugnPay, make sure you have cURL support installed

    unset($response);

    /******************************************************************************************
    * Post order info data to PlugnPay, make sure you have curl installed
    *    Those with cURL not compiled into PHP (Windows users, some Linux users): 
    *          Please type in your path in the admin module.  The code below will TRY to find
    *          your cURL path for you (may not work under Windows) and if it finds it, will
    *          default to that, but you should enter your cURL path in the admin module to be
    *          sure.  You no longer need to edit the code manually in this file (that code thanks
    *          to dreamscape).
    *    Those with cURL compiled into PHP (some Linux users):
    *          This should work without any editing if cURL is compiled into your PHP and you
    *          have PHP configured to realize it (per the PHP guides).
    ********************************************************************************************/

    if (MODULE_PAYMENT_PLUGNPAY_ARB_CURL == 'Not Compiled') {
      if (function_exists('exec')) {
        exec('which curl', $curl_output);
        if ($curl_output) {
          $curl_path = $curl_output[0];
        }
        else {
          $curl_path = MODULE_PAYMENT_PLUGNPAY_ARB_CURL_PATH;
        }
      }
      exec("$curl_path -d \"$data\" https://pay1.plugnpay.com/payment/pnpremote.cgi", $response);
    }
    else {
      $url = "https://pay1.plugnpay.com/payment/pnpremote.cgi";
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_VERBOSE, 0);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);  //Windows 2003 Compatibility 

      # If you use GoDaddy hosting or other hosting service that requires use of a proxy to talk to external sites via cURL,
      # then uncomment the following 3 lines and substitute they proxy server's address for 1.2.3.4 below:

      #curl_setopt ($ch, CURLOPT_HTTPPROXYTUNNEL, true);
      #curl_setopt ($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
      #curl_setopt ($ch, CURLOPT_PROXY, 'proxy.shr.secureserver.net:3128 ');

      $authorize = curl_exec($ch);
      #$commError = curl_error($ch);
      #$commInfo = @curl_getinfo($ch);
      curl_close($ch);
      $response = split(",", $authorize);
    }

    // DATABASE SECTION
    // Insert the send and receive response data into the database.
    // This can be used for testing or for implementation in other applications
    // This can be turned on and off if the Admin Section
    if (MODULE_PAYMENT_PLUGNPAY_ARB_STOREDATA == 'True'){
      // Create a string from all of the response data for insertion into the database
      while(list($key, $value) = each($response)) {
        $response_list .= ($key +1) . '=' . urlencode(ereg_replace(',', '', $value)) . '&';
      }

      // Remove the last "&" from the string
      $response_list = substr($response_list, 0, -1);

      $response_code = explode(',', $response[0]);
      $response_text = explode(',', $response[3]);
      $transaction_id = explode(',', $response[6]);
      $authorization_type = explode(',', $response[11]);

      $db_response_code = $response_code[0];
      $db_response_text = $response_text[0];
      $db_transaction_id = $transaction_id[0];
      $db_authorization_type = $authorization_type[0];
      $db_session_id = zen_session_id();

      // Insert the data into the database
      $db->Execute("insert into " . TABLE_PLUGNPAY_ARB . "  (id, customer_id,order_id, response_code, response_text, authorization_type, transaction_id, sent, received, time, session_id) values ('', '" . $_SESSION['customer_id'] . "', '" . $new_order_id . "', '" . $db_response_code . "', '" . $db_response_text . "', '" . $db_authorization_type . "', '" . $db_transaction_id . "', '" . $data . "', '" . $response_list . "', '" . $order_time . "', '" . $db_session_id . "')");
    }

    ## Note: Enable this code to record the response string to a text file for debug purposes
    if(MODULE_PAYMENT_PLUGNPAY_ARB_TESTMODE == 'Test') {
      $filename = './plugnpay_debug.txt';
      $fp = fopen($filename, "a");
      $write = fputs($fp, "POSTAUTH: $response[0]\n\n");
      fclose($fp);
    }

    # NOTE: windows server users, you must have 'register_globals' ON in your php.ini for parse_str to work correctly.
    parse_str($response[0]);

    # check the FinalStatus for the 'auth' request
    if($FinalStatus == 'success') {
      # // now check FinalStatus for the 'add_member' request.
      # parse_str("$a00001", $response2);
      # if ($response2['FinalStatus'] == 'success') { 
      #   # if everything is OK, let things complete normally
      $db->Execute("delete from " . TABLE_ORDERS . " where orders_id = '" . (int)$insert_id . "'"); //Remove order
      #   #zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, 'error_message=' . urlencode('SUCCESSFUL - ORDER APPROVED'), 'SSL', true, false));  // uncomment this line for testing.
      # }
      # else {
      #   zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, 'error_message=' . urlencode('There was an error processing your transaction.  DO NOT RESUBMIT YOUR PAYMENT.  Please contact the merchant for ordering assistance. -- ') . urlencode($response2['MErrMsg']), 'SSL', true, false));
      # }
    }
    else if($FinalStatus == 'badcard') {
      zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, 'error_message=' . urlencode('Your authorization was declined.  Please try another card.') . urlencode(" -- $MErrMsg"), 'SSL', true, false));
    }
    else if($FinalStatus == 'fraud') {
      zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, 'error_message=' . urlencode('Your transaction was rejected.  Please contact the merchant for ordering assistance.') . urlencode(" -- $MErrMsg"), 'SSL', true, false));
    }
    else if($FinalStatus == 'problem') {
      zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, 'error_message=' . urlencode('There was an error processing your transaction.  Please contact the merchant for ordering assistance.') . urlencode(" -- $MErrMsg"), 'SSL', true, false));
    }
    else {
      if ($response[0] == '') {
        zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, 'error_message=' . urlencode("There was an unspecified error processing your transaction.<br>Received empty cURL response - check cURL connectivity to PnP server.") . urlencode(" -- $MErrMsg"), 'SSL', true, false));
      }
      else {
        zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, 'error_message=' . urlencode("There was an unspecified error processing your transaction.") . urlencode(" -- $MErrMsg"), 'SSL', true, false));
      }
    }
  }

  /**
  * Post-process activities.
  *
  * @return boolean
  */
  function after_process() {
    global $insert_id, $db;
    $db->Execute("insert into " . TABLE_ORDERS_STATUS_HISTORY . " (comments, orders_id, orders_status_id, date_added) values ('Credit Card payment.  AUTH: " . $this->auth_code . ". TransID: " . $this->transaction_id . ".' , '". (int)$insert_id . "','" . $this->order_status . "', now() )");
    return false;
  }

  /**
  * Used to display error message details
  *
  * @return array
  */
  function get_error() {
    global $_GET;
    $error = array('title' => MODULE_PAYMENT_PLUGNPAY_ARB_TEXT_ERROR,
                   'error' => stripslashes(urldecode($_GET['error'])));
    return $error;
  }

  /**
  * Check to see whether module is installed
  *
  * @return boolean
  */
  function check() {
    global $db;
    if (!isset($this->_check)) {
      $check_query = $db->Execute("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_PLUGNPAY_ARB_STATUS'");
      $this->_check = $check_query->RecordCount();
    }
    return $this->_check;
  }

  /**
  * Install the payment module and its configuration settings
  *
  */
  function install() {
    global $db;
   $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Enable PlugnPay ARB Module', 'MODULE_PAYMENT_PLUGNPAY_ARB_STATUS', 'True', 'Do you want to accept recurring PlugnPay payments via the ARB Method?', '6', '0', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Login ID', 'MODULE_PAYMENT_PLUGNPAY_ARB_LOGIN', 'testing', 'The API Login ID used for the PlugnPay service', '6', '0', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Login Password', 'MODULE_PAYMENT_PLUGNPAY_ARB_PASSWD', 'Test', 'The API Login Password used for the PlugnPay service', '6', '0', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Publisher-Email', 'MODULE_PAYMENT_PLUGNPAY_ARB_PUBEMAIL', 'you@yourdomain.com', 'Merchant Confirmation & Notification Email address used by the PlugnPay service', '6', '0', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('CURL Setup', 'MODULE_PAYMENT_PLUGNPAY_ARB_CURL', 'Not Compiled', 'Whether CURL is compiled into PHP or not.  Windows users, select not compiled.', '6', '0', 'zen_cfg_select_option(array(\'Not Compiled\', \'Compiled\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('cURL Path', 'MODULE_PAYMENT_PLUGNPAY_ARB_CURL_PATH', 'The Path To CURL', 'For Not Compiled mode only, input path to the cURL binary (i.e. Windows: c:/curl/curl, Linux: /usr/bin/curl)', '6', '0', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Authorization Type', 'MODULE_PAYMENT_PLUGNPAY_ARB_AUTHTYPE', 'authonly', 'Do you want submitted credit card transactions to be authorized only, or authorized and captured?', '6', '0', 'zen_cfg_select_option(array(\'authonly\', \'authpostauth\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Prevent PnP Notification', 'MODULE_PAYMENT_PLUGNPAY_ARB_EMAILCUST', 'yes', 'Would you like to prevent PlugnPay from sending customer confirmation emails?', '6', '0', 'zen_cfg_select_option(array(\'yes\', \'no\'), ', now())");
    // Future: set_function, use_function ... 'zen_cfg_password_input(', 'zen_cfg_password_display'
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Transaction Mode', 'MODULE_PAYMENT_PLUGNPAY_ARB_TESTMODE', 'Test', 'Transaction mode used for processing orders', '6', '0', 'zen_cfg_select_option(array(\'Test\', \'Production\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Billing Cycle Interval', 'MODULE_PAYMENT_PLUGNPAY_ARB_BILLCYCLE', '1', 'The measurement of time \[in Months\], that is used to define the frequency of the billing occurrences. (Cannot exceed 36 months)', '6', '0', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Total Occurrences', 'MODULE_PAYMENT_PLUGNPAY_ARB_TOTAL_OCCURRENCES', '1', 'Number of billing occurrences or payments for the subscription (not including initial sign-up payment)', '6', '0', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Total Discount', 'MODULE_PAYMENT_PLUGNPAY_ARB_TRIAL_DISCOUNT', '0', 'Dollar Amount to discount during the trial period. Enter \'full\' for a 100% discount', '6', '0', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Request CVV Number', 'MODULE_PAYMENT_PLUGNPAY_ARB_USE_CVV', 'True', 'Do you want to ask the customer for the card\'s CVV number', '6', '0', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Enable Database Storage', 'MODULE_PAYMENT_PLUGNPAY_ARB_STOREDATA', 'False', 'Do you want to save the gateway data to the database? (Note: You must add a table first)', '6', '0', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Sort order of display.', 'MODULE_PAYMENT_PLUGNPAY_ARB_SORT_ORDER', '0', 'Sort order of display. Lowest is displayed first.', '6', '0', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, use_function, set_function, date_added) values ('Payment Zone', 'MODULE_PAYMENT_PLUGNPAY_ARB_ZONE', '0', 'If a zone is selected, only enable this payment method for that zone.', '6', '2', 'zen_get_zone_class_title', 'zen_cfg_pull_down_zone_classes(', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Order Status', 'MODULE_PAYMENT_PLUGNPAY_ARB_ORDER_STATUS_ID', '0', 'Set the status of orders made with this payment module to this value', '6', '0', 'zen_cfg_pull_down_order_statuses(', 'zen_get_order_status_name', now())");
  }

  /**
  * Remove the module and all its settings
  *
  */
  function remove() {
    global $db;
    $db->Execute("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
  }

  /**
  * Internal list of configuration keys used for configuration of the module
  *
  * @return array
  */
  function keys() {
    return array('MODULE_PAYMENT_PLUGNPAY_ARB_STATUS', 'MODULE_PAYMENT_PLUGNPAY_ARB_LOGIN', 'MODULE_PAYMENT_PLUGNPAY_ARB_PASSWD', 'MODULE_PAYMENT_PLUGNPAY_ARB_PUBEMAIL', 'MODULE_PAYMENT_PLUGNPAY_ARB_CURL', 'MODULE_PAYMENT_PLUGNPAY_ARB_CURL_PATH', 'MODULE_PAYMENT_PLUGNPAY_ARB_AUTHTYPE', 'MODULE_PAYMENT_PLUGNPAY_ARB_EMAILCUST', 'MODULE_PAYMENT_PLUGNPAY_ARB_TESTMODE', 'MODULE_PAYMENT_PLUGNPAY_ARB_BILLCYCLE', 'MODULE_PAYMENT_PLUGNPAY_ARB_TOTAL_OCCURRENCES', 'MODULE_PAYMENT_PLUGNPAY_ARB_TRIAL_DISCOUNT', 'MODULE_PAYMENT_PLUGNPAY_ARB_USE_CVV', 'MODULE_PAYMENT_PLUGNPAY_ARB_STOREDATA', 'MODULE_PAYMENT_PLUGNPAY_ARB_SORT_ORDER', 'MODULE_PAYMENT_PLUGNPAY_ARB_ZONE', 'MODULE_PAYMENT_PLUGNPAY_ARB_ORDER_STATUS_ID');
  }
}

