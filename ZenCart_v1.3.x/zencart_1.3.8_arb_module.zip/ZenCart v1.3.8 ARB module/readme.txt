====================================================
PlugnPay Simple ARB (Automatic Recur Billing) Module
Payment Module for ZenCart v1.3.8
====================================================

***** IMPORTANT NOTES *****
This module is being provided "AS IS".  Limited technical support assistance will
be given to help diagnose/address problems with this module.  The amount of support
provided is up to PlugnPay's staff.

It is recommended if you experience a problem with this module, first seek assistance
through this module's readme file, then check with the ZenCart community at
'www.zencart.com', and if you are still unable to resolve the issue, contact us
via PlugnPay's Online Helpdesk.

This module requires your server to have SSL abilities & CURL.  ZenCart will ask the
customer for all of their credit card info on your server's SSL secured billing pages.
The authorization will be done via PlugnPay's API payment method.  The module is
intended to itemize the order in the PlugnPay system using available information from
the cart & handle any additional/future recurring payments automatically via PlugnPay's
Membership Management service.

You MUST be subscribed to & setup with PlugnPay's Membership Management Service
[with the Installment Billing option enabled] prior to attempting to use this
payment module; as this additional PlugnPay service required to store the customer's
CC information & automatically charge the remaining payments as directed.

If you want to change the behavior of this module, please feel free to make changes
to the files yourself.  However, customized ZenCart modules will not be provided
support assistance.

In addition, you should have the 'Enable secure SSL/HTTPS connections' option enabled
in your ZenCart shopping cart to properly use this module.
***************************


This module is designed to use PlugnPay's API payment method, via cURL.
Subscription management is handled in your merchant interface on PlugnPay, not in ZenCart.

================== I M P O R T A N T _ W A R N I N G ============================
%% YOU MUST BE SUBSCRIBED TO & SETUP WITH OUR MEMBERSHIP MANAGEMENT SERVICE,   %%
%% W/INSTALLMENT BILLING OPTION ENABLED, BEFORE ATTEMPTING TO USE THIS MODULE. %%
================================================================================= 

This module is intended to break-up customer's order into 2 or more payments.
-- The first payment is applied at time of the customer's purchase.
-- The balance of the order will be automatically billed via PnP's membership service.

Upon settings defined, merchant can apply the payment structure the following ways:

  ==> Equal Payments - initial payment & remaining payments are all equal $ amounts.
        Example: - Customer places an order for $100.
                 - Module is setup to pay in four payments [initial payment + 3 occurrences]
                     [i.e. $100 total / 4 payments = $25 per payment]
                 - Customer would be charged a $25 payment at time of purchase.
                 - The balance of the order would be $75.
                     [i.e. $100 total - $25 init payment = $75 balance]
                 - Customer would be charged $25 for the remaining 3 payments
                     [i.e. $75 balance / 3 remain payments = $25 per payment]
 
  ==> Discounted Payment - initial payment discounted.  Remaining balace paid in equal amounts.
         Example: - Customer places an order for $100.
                  - Module is setup to pay in four payments [initial payment + 3 occurrences]
                     [i.e. $100 total / 4 payments = $25 per payment]
                  - Module is setup to discount $10 from initial payment
                  - Customer would be charged a $15 payment at time of purchase.
                     [i.e. ($100 total / 4 payments) - $10 discount =  $15 init payment]
                  - The balance of the order would be $85.
                     [i.e. $100 total - $15 init payment = $85 balance]
                  - Customer would be charged $28.33 for the remaining 3 payments
                     [i.e. $85 balance / 3 remain payments = $28.33 per payment]
 
  ==> No Initial Payment - no initial payment. Full amount paid in equal payments 
         Example: - Customer places an order for $100.
                  - Module is setup to pay in four payments [initial payment + 3 occurrences]
                     [i.e. $100 total / 4 payments = $25 per payment]
                  - Module is setup to skip initial payment
                  - Customer would be charged a $0 payment at time of purchase.
                  - The balance of the order would be $100.
                     [i.e. $100 total - $0 init payment = $100 balance]
                  - Customer would be charged $33.33 for the remaining 3 payments
                     [i.e. $100 balance / 3 remain payments = $33.33 per payment]
                       (* Note: the extra penny is automatically applied to last payment.)


To Install:

1. Copy the zencart_root/includes/languages/english/modules/payment/plugnpay_arb.php file to the
corresponding file in your zencart install on your web server.

2. Do the same with zencart_root/modules/payment/plugnpay_arb.php

3. Copy the plugnpay_debug.txt file to root folder where zencart is installed on your web server.

4. Go into your admin panel and activate the PlugnPay ARB payment module on the payment modules
page and fill in the appropriate data


If you run into problems:

Check to be sure you actually uploaded the files in the correct folders.

Check the uploaded file's permissions:
-- .php files should be chmod 755
   (read/write/execute by owner, read/execute by all others)
-- .txt files should be chmod 666
   (read/write by all [owner, group & nobody user])

When processing a transaction and it fails, there should be a PnP generated error 
message after the '--' in the response in your shopping cart.  This would tell the 
customer why PnP could not process the order.  If this is blank, then you should check
your cURL connection. 

There are 2 ways to check the cURL connection:

1 - Turn on the Test option, run a transaction and then look at the 
    'plugnpay_debug.txt' file in your catalog folder.
    -- The PREAUTH line is the string that was sent to PnP's servers via the cURL 
       connection.
    -- The POSTAUTH line is the string that was received by your cURL connection from
       PnP server.
    -- When the POSTAUTH line is blank, this means cURL did not make a connection to 
       PnP servers & is best to manually test cURL with the 2nd way below. 

2 - You can check this out by accessing the server via a shell account (SSH/Telnet) & 
    manually running a cURL connection.
    Run the following command from the command line of the server's shell and see if you 
    get a response string.

   /usr/bin/curl -d "publisher-name=pnpdemo&publisher-email=trash%40plugnpay.com&mode=auth&card-name=cardtest&card-number=4111111111111111&card-exp=0112&card-cvv=123&card-amount=1.23" https://pay1.plugnpay.com/payment/pnpremote.cgi
 

 *NOTES:
 -- THE ABOVE COMMAND SHOULD ALL BE ON ONE LINE
 -- You should adjust the path to curl (/usr/bin/curl) to whatever your server uses.
 -- You should get a response string similar to the one below.
 
 You should get a response string should look something like this, if it was successful.

FinalStatus=success&IPaddress=123%2e45%2e67%2e89&MStatus=success&User%2dAgent=curl%2f7%2e12%2e1%20%28i386%2dredhat%2dlinux%2dgnu%29%20libcurl%2f7%2e12%2e1%20OpenSSL%2f0%2e9%2e7a%20zlib%2f1%2e2%2e2%2e2%20libidn%2f0%2e5%2e6&auth%2dcode=TSTAUT&auth%2dmsg=%2000%3a&auth_date=20060718&avs%2dcode=U&card%2damount=1%2e23&card%2dname=cardtest&card%2dtype=VISA&currency=usd&cvvresp=M&easycart=0&merchant=pnpdemo&mode=auth&orderID=2006071821390221195&publisher%2demail=trash%40plugnpay%2ecom&publisher%2dname=pnpdemo&resp%2dcode=00&resphash=a84f2bf05b83fc7677e7da9ded14d8f3&shipinfo=0&sresp=A&success=yes&transflags=retail&MErrMsg=00%3a&a=b

 * NOTE: THE ABOVE SHOULD ALL BE ON ONE LINE

If you get a certificate validation error, you can enter '-k' attribute between the path 
to curl & the '-d' parameter.  The '-k' parameter will turn off the SSL certificate 
validation.
 
If you get back a blank response there is most likely a firewall which is internal to 
your server/network which is preventing cURL from contacting our servers.
 
If cURL complied into your PHP is not working, but the command line cURL connection 
worked, use Not Compiled option & that same path to curl you used in your command line.

If this hasn't still fixed the issue, here are a few other suggestions.  You may want
to check the following: 

  * Ensure your path to cURL is correctly inputted, if in Not Compiled mode.

  * If in Compiled mode, check if cURL is in fact compiled and working.

  * Ensure SSL abilities on your server are working & updated with the latest certificates.

  * Remove & then Install the PlugnPay ARB module via the Admin panel, if you upgraded
    from a previous version or modified the source code of any of our module's files.

  * Ensure your PlugnPay username is inputted correctly into the Login ID field.

  * Ensure your PlugnPay password is inputted correctly into the Login Password field.

  * Ensure your PlugnPay account is actually 'Live' & ZenCart is set in Production status, 
    so you can process real credit card transactions.

  * Ensure you have properly set up your PlugnPay account via our website, including setting
    all your Fraud settings & make sure your account is 'Live'.

  * Make sure you registered your server's IP addres within your PlugnPay
    account's Security Adminstration area.  Without this, the module will be
    unable to add new members to your Membership Management service.

Also, realize that this code itself is not very complex, and practically every person 
that has contacted us about errors found that some other code not associated with this
contribution was responsible, or because their cURL implementation was not properly set 
up or working.  Do your own debugging before contacting anyone for assistance.

-----------------------------------------------------------------------------
Updates:

12/04/08
-- wrote initial ZenCart ARB API module, specifically for ZenCart build v1.3.8
-- tried to give similar features/options as previous ZenCart modules.

12/13/08
-- applied several bug fixes
-- updated a few of the offered features
-- added a few sanity checks to help prevent problems during calculations
-- updated this README document

12/26/08
- cleaned up module's code base
- added extra text to clarify CURL path details
- adjusted code to permit multiple PnP modules to be used at one time.
- added merchant confirmation & notification email setting
- added code to verify the 'add_member' requests worked correctly.

01/28/09
- fixed enddate bug

